--
-- PostgreSQL database dump
--

\restrict Ay9JvPoPzwrVnEAI1eiD0p44YGNHJxW7Pl6Ztfw6l7CEuPrJmcMokjNkzDXaFhq

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_devices DROP CONSTRAINT IF EXISTS user_devices_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_parent_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.task_labels DROP CONSTRAINT IF EXISTS task_labels_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_labels DROP CONSTRAINT IF EXISTS task_labels_label_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_assignees DROP CONSTRAINT IF EXISTS task_assignees_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_assignees DROP CONSTRAINT IF EXISTS task_assignees_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.saved_filters DROP CONSTRAINT IF EXISTS saved_filters_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.saved_filters DROP CONSTRAINT IF EXISTS saved_filters_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mcp_tokens DROP CONSTRAINT IF EXISTS mcp_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.labels DROP CONSTRAINT IF EXISTS labels_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ingest_keys DROP CONSTRAINT IF EXISTS ingest_keys_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ingest_keys DROP CONSTRAINT IF EXISTS ingest_keys_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.error_reports DROP CONSTRAINT IF EXISTS error_reports_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.error_reports DROP CONSTRAINT IF EXISTS error_reports_linked_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.error_reports DROP CONSTRAINT IF EXISTS error_reports_assignee_id_fkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.activities DROP CONSTRAINT IF EXISTS activities_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.activities DROP CONSTRAINT IF EXISTS activities_task_id_fkey;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_user_devices_user;
DROP INDEX IF EXISTS public.ix_tasks_status;
DROP INDEX IF EXISTS public.ix_task_project_status;
DROP INDEX IF EXISTS public.ix_task_parent;
DROP INDEX IF EXISTS public.ix_mcp_tokens_token_hash;
DROP INDEX IF EXISTS public.ix_ingest_keys_token;
DROP INDEX IF EXISTS public.ix_ingest_keys_project;
DROP INDEX IF EXISTS public.ix_error_reports_project_status;
DROP INDEX IF EXISTS public.ix_error_reports_last_seen;
DROP INDEX IF EXISTS public.ix_comments_task;
DROP INDEX IF EXISTS public.ix_activities_task;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_devices DROP CONSTRAINT IF EXISTS user_devices_pkey;
ALTER TABLE IF EXISTS ONLY public.user_devices DROP CONSTRAINT IF EXISTS user_devices_fcm_token_key;
ALTER TABLE IF EXISTS ONLY public.labels DROP CONSTRAINT IF EXISTS uq_label_project_name;
ALTER TABLE IF EXISTS ONLY public.error_reports DROP CONSTRAINT IF EXISTS uq_error_project_signature;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.task_labels DROP CONSTRAINT IF EXISTS task_labels_pkey;
ALTER TABLE IF EXISTS ONLY public.task_assignees DROP CONSTRAINT IF EXISTS task_assignees_pkey;
ALTER TABLE IF EXISTS ONLY public.saved_filters DROP CONSTRAINT IF EXISTS saved_filters_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.mcp_tokens DROP CONSTRAINT IF EXISTS mcp_tokens_token_hash_key;
ALTER TABLE IF EXISTS ONLY public.mcp_tokens DROP CONSTRAINT IF EXISTS mcp_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.labels DROP CONSTRAINT IF EXISTS labels_pkey;
ALTER TABLE IF EXISTS ONLY public.ingest_keys DROP CONSTRAINT IF EXISTS ingest_keys_token_hash_key;
ALTER TABLE IF EXISTS ONLY public.ingest_keys DROP CONSTRAINT IF EXISTS ingest_keys_pkey;
ALTER TABLE IF EXISTS ONLY public.error_reports DROP CONSTRAINT IF EXISTS error_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_pkey;
ALTER TABLE IF EXISTS ONLY public.app_settings DROP CONSTRAINT IF EXISTS app_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS ONLY public.activities DROP CONSTRAINT IF EXISTS activities_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_devices;
DROP TABLE IF EXISTS public.tasks;
DROP TABLE IF EXISTS public.task_labels;
DROP TABLE IF EXISTS public.task_assignees;
DROP TABLE IF EXISTS public.saved_filters;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.mcp_tokens;
DROP TABLE IF EXISTS public.labels;
DROP TABLE IF EXISTS public.ingest_keys;
DROP TABLE IF EXISTS public.error_reports;
DROP TABLE IF EXISTS public.comments;
DROP TABLE IF EXISTS public.app_settings;
DROP TABLE IF EXISTS public.alembic_version;
DROP TABLE IF EXISTS public.activities;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.activities (
    id uuid NOT NULL,
    task_id uuid NOT NULL,
    user_id uuid,
    kind character varying NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.activities OWNER TO tareapp;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO tareapp;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.app_settings (
    key character varying NOT NULL,
    value character varying NOT NULL
);


ALTER TABLE public.app_settings OWNER TO tareapp;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.comments (
    id uuid NOT NULL,
    task_id uuid NOT NULL,
    author_id uuid,
    body character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.comments OWNER TO tareapp;

--
-- Name: error_reports; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.error_reports (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    signature character varying NOT NULL,
    app character varying DEFAULT ''::character varying NOT NULL,
    environment character varying DEFAULT 'prod'::character varying NOT NULL,
    level character varying DEFAULT 'error'::character varying NOT NULL,
    title character varying NOT NULL,
    message character varying DEFAULT ''::character varying NOT NULL,
    stack_trace character varying DEFAULT ''::character varying NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    first_seen timestamp without time zone DEFAULT now() NOT NULL,
    last_seen timestamp without time zone DEFAULT now() NOT NULL,
    occurrences integer DEFAULT 1 NOT NULL,
    status character varying DEFAULT 'new'::character varying NOT NULL,
    linked_task_id uuid,
    assignee_id uuid,
    release character varying DEFAULT ''::character varying NOT NULL,
    kind character varying DEFAULT 'error'::character varying NOT NULL
);


ALTER TABLE public.error_reports OWNER TO tareapp;

--
-- Name: ingest_keys; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.ingest_keys (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    name character varying NOT NULL,
    token_hash character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    last_used_at timestamp without time zone,
    created_by uuid
);


ALTER TABLE public.ingest_keys OWNER TO tareapp;

--
-- Name: labels; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.labels (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    name character varying NOT NULL,
    color character varying DEFAULT '#94a3b8'::character varying NOT NULL
);


ALTER TABLE public.labels OWNER TO tareapp;

--
-- Name: mcp_tokens; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.mcp_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying NOT NULL,
    token_hash character varying NOT NULL,
    last_used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    revoked_at timestamp without time zone
);


ALTER TABLE public.mcp_tokens OWNER TO tareapp;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    name character varying NOT NULL,
    description character varying,
    color character varying DEFAULT '#6366f1'::character varying NOT NULL,
    owner_id uuid NOT NULL,
    property_schema jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    kanban_settings jsonb DEFAULT '{"density": "normal", "group_by": "status", "visible_props": []}'::jsonb NOT NULL,
    status_schema jsonb DEFAULT '[{"key": "todo", "color": "#94a3b8", "group": "todo", "label": "Por hacer"}, {"key": "doing", "color": "#3b82f6", "group": "doing", "label": "En curso"}, {"key": "done", "color": "#10b981", "group": "done", "label": "Hecho"}, {"key": "archived", "color": "#64748b", "group": "done", "label": "Archivado"}]'::jsonb NOT NULL,
    feedback_enabled boolean DEFAULT false NOT NULL,
    icon character varying
);


ALTER TABLE public.projects OWNER TO tareapp;

--
-- Name: saved_filters; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.saved_filters (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.saved_filters OWNER TO tareapp;

--
-- Name: task_assignees; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.task_assignees (
    task_id uuid NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.task_assignees OWNER TO tareapp;

--
-- Name: task_labels; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.task_labels (
    task_id uuid NOT NULL,
    label_id uuid NOT NULL
);


ALTER TABLE public.task_labels OWNER TO tareapp;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.tasks (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    parent_task_id uuid,
    title character varying NOT NULL,
    description character varying DEFAULT ''::character varying NOT NULL,
    status character varying DEFAULT 'todo'::character varying NOT NULL,
    priority character varying DEFAULT 'normal'::character varying NOT NULL,
    due_date date,
    "position" integer DEFAULT 0 NOT NULL,
    created_by uuid,
    properties jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    due_date_end date,
    icon character varying,
    cover_url character varying
);


ALTER TABLE public.tasks OWNER TO tareapp;

--
-- Name: user_devices; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.user_devices (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    fcm_token character varying NOT NULL,
    platform character varying DEFAULT 'android'::character varying NOT NULL,
    last_seen timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_devices OWNER TO tareapp;

--
-- Name: users; Type: TABLE; Schema: public; Owner: tareapp
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying NOT NULL,
    name character varying NOT NULL,
    password_hash character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    role character varying DEFAULT 'member'::character varying NOT NULL
);


ALTER TABLE public.users OWNER TO tareapp;

--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.activities (id, task_id, user_id, kind, payload, created_at) FROM stdin;
507c62f4-f9a8-42fa-87ea-e6efca1977fa	3b29ae36-c2d1-4c5a-a5ba-419a67bdb080	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Tasks Con triggers"}	2026-05-21 23:11:07.968914
4190faf9-64f1-4e1b-9838-fe364d6beeeb	7234bb95-02ed-4933-8446-0cf87071d4fa	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Arreglos al sistema de tareas"}	2026-05-21 23:11:08.700263
a568569e-98c3-46ac-a2ab-eb1a2f78343c	eafd0a2b-9538-46d8-94c1-05dd188a6435	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Mejorar estrategia de procesamiento de excels"}	2026-05-21 23:11:09.446107
b7c65c76-7fc2-4e9c-bf5c-bcec45151967	f0b4ca8b-c85e-4576-ae8c-00a76eea6289	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Revisar todas las funcionalidades del helper y el builder dejar comentarios en esta tarea con los problemas que se encuentren"}	2026-05-21 23:11:10.114411
11eb7bc3-3474-45eb-827f-e73232d32e36	f2c84d5d-229d-4ee3-abdb-526272657aca	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Arreglar seleccionar tools en crear agente"}	2026-05-21 23:11:10.861323
cfa980a0-1685-4c60-ac57-42d50dc2e718	5c2f07d1-2b71-4585-9f53-b798c31ed4a8	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Chat de oficina con cambio de agente"}	2026-05-21 23:11:11.445457
e9b986fe-9fe3-452a-89f9-d138d8d2f77e	10d138c7-9526-40f9-997c-bb0c69b4b346	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Mejoras progresivas en los agentes"}	2026-05-21 23:11:12.072685
bdd0b20d-6a72-4455-884c-22eb91a4f691	5f78cc16-c2c3-45fe-a7fe-98e834805e5d	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Agregar credenciales de herramientas a las oficinas importadas"}	2026-05-21 23:11:12.667647
98617000-24dc-4f75-924b-a50c92559201	810fc5f4-dcc1-45e1-b566-4aeacc8a75c3	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Arreglar Plan del Helper"}	2026-05-21 23:11:13.435651
1222ef76-e533-497c-b00b-4cd6e47893c7	48b7cd07-2a59-4dcf-b759-59e0b92ce8fe	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Arreglar Configuración de canales con el helper"}	2026-05-21 23:11:14.184098
9d687e6a-07f8-42f8-be72-3443aa894c10	756d304e-bf14-4cac-83cd-b680d01b4fb3	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Eliminar del marketplace las siguientes integraciones"}	2026-05-21 23:11:14.804773
0e4ae52f-2902-4cd7-b2ed-9319103ebeb7	7c91ad58-443d-4931-bbf2-a6581a299092	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Mejorar UI Tools"}	2026-05-21 23:11:15.550859
dbcb3f65-2178-46d3-8443-292c30499edb	059cbad3-21fc-49a0-a217-33f4d3b0a250	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Durante la creación de los agentes seleccion del modelo"}	2026-05-21 23:11:16.224659
1ec6539e-668d-4888-af75-9ebb6bd4618f	2a3ba5be-b906-42aa-bc39-0c45217fa3af	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Providers remotes"}	2026-05-21 23:11:17.582372
023f8d74-61e0-4679-a6e8-1521368ec9d7	312bd9ce-f26c-4706-af20-057e2261b5de	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Cuando se crea una oficina con el helper no se esta configurando el manager"}	2026-05-21 23:11:18.332862
da33fe4a-10ca-4a12-8956-13065ea48e4b	d2161c26-0729-437a-b321-75117b16514b	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Bug ollama provider local"}	2026-05-21 23:11:19.126807
952ed6bb-2c11-4f0e-90b0-1036b0ae7510	6a42843a-2ade-420c-aa95-bde9cf834aad	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Error remote providers"}	2026-05-21 23:11:19.839497
2dacb9de-42fe-4a27-8e73-dd890b561d89	9fcdb127-10d5-498f-836d-6eb77ff6b109	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Las herramientas con autenticacion deben pder tener mas de una credencial y asignar las credenciales a los agentes"}	2026-05-21 23:11:20.46959
c759efdf-a4a1-4c0e-8b8e-646e55c1a1cf	e3f5eeaa-93ea-495b-8003-24f43b054325	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "El error en el flujo de conversación del chat global"}	2026-05-21 23:11:21.174681
8505cb6d-5ca6-446b-8a53-aef92653a3fd	12a78b26-88ae-4cad-b53b-ece1f81cb20a	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Arreglar el chat 2"}	2026-05-21 23:11:21.880915
dffa04c2-fdc0-4130-ad73-b4d5f8afac93	9470bcdc-3002-4fa3-8688-483a465fced9	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Agregar disparadores"}	2026-05-21 23:11:22.502928
f2118d26-263f-4477-9e7e-b60d6da235a2	a06d86c0-8b36-4a64-be44-0afe77da49f6	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Soporte para tools con ollama cloud"}	2026-05-21 23:11:23.127095
fa7ba4b8-5946-4bb9-8214-1317d21a62de	1b450e94-25fb-4058-8dad-7a9c276e3964	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "No se guardan los cambios en la configuración de canal de wsapp"}	2026-05-21 23:11:23.927516
eed16f57-e35d-43a4-9daa-de6e4536a8f9	94b7fafa-1808-4394-a5f1-71480b827071	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Implementar CAK (Context-Aware Knowledge) en LangChain"}	2026-05-21 23:11:24.699
8d86091c-217b-46fe-af56-d4a36ec83767	02508451-ff21-4883-bbf2-dc0ef63f7388	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Sanear keys eliminando caracteres de mas al inicio y al final"}	2026-05-21 23:11:25.335412
4ad668a3-5c49-4a3c-a0b1-cc14c90d7f21	c9167178-1aac-4b79-8095-b9599fe9a793	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Arreglar providers hardcodeados en el modal de crear agente"}	2026-05-21 23:11:26.087546
f0bcbb85-79c5-40c8-84b9-d8c1a02613b1	6a0c5d2b-d158-4647-bd18-0b607d214564	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Arreglar traducción a inglés"}	2026-05-21 23:11:26.839597
5b5f7463-7dc4-4b3e-aaa9-43273844cac5	11cb856f-679f-47a8-9583-069cf8f73c08	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Planificar instalación automatica del entorno aislado"}	2026-05-21 23:11:27.587946
f360daf3-5521-4f9d-9d3b-45d6a8e2863e	aa19b18d-4b0c-4743-9629-5c067b624267	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Traducir systempromts a inglés"}	2026-05-21 23:11:28.252395
6fe67a71-ab22-4679-b968-66664e2838e2	9d1e3f1a-f3af-437d-bc9e-5e562b1a9dae	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Ajustar las skills"}	2026-05-21 23:11:28.880331
a0f4dbf6-cc6c-413b-a9b8-310784957895	f0dbb3e1-f966-44bc-a31d-8bbaa3a4c66d	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Al crear un agente desde el chat de oficina, y cambias a la vista de equipo, se actualiza y no se ven los nuevos agentes"}	2026-05-21 23:11:29.631459
4b9aa0a7-6899-4ac2-9a0e-4e2f1553e74a	4c6b044a-f7b6-4943-ba98-56416125c989	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Eliminar la vista avanzada"}	2026-05-21 23:11:30.421477
893e5534-5ede-4745-af34-84785fc83f38	dd4efb77-96e3-4c92-a25d-f07063840cf4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Error en el chat global al manger llamar a determinados agentes (Frontend)"}	2026-05-21 23:11:31.174756
8798f11f-b17f-4c85-98c7-4e3ca735aa03	ff5949f5-9a58-41d9-a7d8-dfec2e0be590	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Los agentes conectados a wsapp no son capaces de mandar imágenes"}	2026-05-21 23:11:31.926118
5967e42b-9367-453c-80cd-6a4fa7adfe59	1299f8cd-8569-4293-ba1e-dd55990b65e4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "El agente constructor en el formulario no selecciona la credencial del proveedor LLM"}	2026-05-21 23:11:32.68009
450b4b0b-3bb8-4c2a-8dc7-d5ed61b41f3b	d641b717-a973-46fe-aa06-abaf0f035c60	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Cantidad de documentos seleccionables al crear la base de datos"}	2026-05-21 23:11:33.429794
8458f029-c8d2-4b27-b27f-bd019701c416	175fd510-ddb1-4e7e-8b62-7f0a113156ab	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "SI mientras se esta subiendo un documento se le asigna la base de conocimiento a un agente se deja de subir el documento"}	2026-05-21 23:11:34.223489
c0eb540d-13f0-444f-9509-3626af8fe26f	3c757953-612e-4cde-a385-670c0da10e97	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Cuando estas creando un agente con el builder no te selecciona la ApiKey del modelo que le vas a poner"}	2026-05-21 23:11:34.849604
7f0a5b82-20b0-4dab-b963-aa2b135693d4	799e9363-5930-4f0e-bebf-f40a6aacf210	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Respuesta del agente invocado por disparador en el chat"}	2026-05-21 23:11:35.63816
c87b764c-aaa4-428b-8642-d28791b427c5	43dca3b0-ed8e-487f-a4fc-53db604c7cd4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Error durante la creación de oficinas con Tadiin helper"}	2026-05-21 23:11:36.38526
9b9354b0-6c27-4ea0-8bee-493ff9bec0fa	1c98ac95-5737-4f1a-8f59-55b13f974224	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Cola de agente por provider"}	2026-05-21 23:11:37.132869
571d25c9-84c0-420d-bcac-f53352f19db5	8878cc8d-6e8a-42aa-9c1c-206deceab9ed	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Error al crear una instancia de wsapp con el builder"}	2026-05-21 23:11:37.880616
3b692d2f-dddd-41b1-9335-885f08748f03	6361eefe-7be4-42a8-8ee4-c9a6d690c034	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Error en las seciones de chat"}	2026-05-21 23:11:38.674015
fde4cc50-b648-4c87-b8e1-8fde1bc9413a	9cdb8c28-fcbc-4a1f-8a46-85ad6b8c7183	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "seguir el chat con un agente especifico en el chat de oficina"}	2026-05-21 23:11:39.461533
cbd87c7d-e22f-42a7-804c-84eda2a54141	fd4519d5-f261-4a29-a262-cab6682fb9a2	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Sistema de scoring para decision a q agente delegar tareas"}	2026-05-21 23:11:40.210676
91d1515d-94b1-4949-b618-76df7ba5cf86	61647beb-8690-4db9-b91f-bbc1f3d014a4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Cuando se va a editar un agente no se ve ni la descripción ni el system promt"}	2026-05-21 23:11:40.958373
e53ba5a4-6687-447e-a6ff-47da5732ef15	42cb8560-2f39-4336-8c11-31306a1a1038	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "mientras el agente esta estrimeando no se puede hacer scroll hacia arriba"}	2026-05-21 23:11:41.670851
17b92563-6b4c-44dc-aaaa-78d0a05a060d	76213fa5-65bd-4d01-af55-8939ad83a4d5	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Implementar tools como modulos"}	2026-05-21 23:11:42.422462
35cae5f1-861f-4013-87df-67a9a1763db2	6363e67d-12e2-4749-a2b1-20ac454f6812	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Ajustar respuestas de agentes para considerar mejor el contexto"}	2026-05-21 23:11:43.09478
da2e2fca-123e-4903-ab8e-1cb293faab1d	f65cd435-eea0-4854-9ef9-b1c27ec896ba	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Implementar OpenRouter como provider"}	2026-05-21 23:11:43.854427
b681a01c-fc73-40aa-88ce-e4704d7c098d	aafbdd9e-4957-42bc-aa95-f4e80e8494a5	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Implementar la funcionalidad para desactivar el think en lm studio"}	2026-05-21 23:11:44.489875
5b4af383-52b6-449b-b3b2-b66d485a5882	45637336-9b66-473d-9d81-37afe371a880	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Arreglar boton de Nueva ApiKey en el Paso 2 de crear agente y en herramientas modificar la vista"}	2026-05-21 23:11:45.121874
faaab36e-1e5b-4c5c-bb58-4b965d49ef57	76b895bf-14ed-48a9-b4f9-afb5de5be5fb	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Implementar funcion para cambiar agentes de oficina"}	2026-05-21 23:11:45.831706
6a7d6859-8122-434f-9908-f64911157cae	d2dbb8f0-bff0-48b2-94b2-e25c3e0a2155	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Agregar validaciones a formularios de Agentes, Tools, Skills y MCP para evitar nombres duplicados"}	2026-05-21 23:11:46.629636
a95d3603-61f3-4d0c-9d30-92dc330a41f7	adafe8d4-99d5-49ca-824d-e237071b9c57	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Mejorar herramienta pdf que permita edicion y lectura"}	2026-05-21 23:11:47.336164
80402ad5-ae09-4f13-8578-a301d21ef0da	11e32319-774e-4b97-9aef-cec2cafd3920	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Ajustes en la UI para streaming en preview de agentes (Sidebar)"}	2026-05-21 23:11:48.130522
71ab5e13-26c1-4ab0-b274-a68eaaecee31	9a263964-0b5f-46ca-9098-585809bd7818	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Mejorar la vista del panel lateral para que se vean mas humanos"}	2026-05-21 23:11:48.931012
2d139baa-e32c-4ba7-aee7-ff0b034c72e0	012eeb8d-dc7d-41a3-95f8-959334083f04	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Agregar HITL a las conversaciones de los chats interagentes"}	2026-05-21 23:11:49.555881
9ef3f60a-2210-4a25-b2c8-d03b073c667e	d44f86de-47fa-4b72-8ea1-adfbeb0025e9	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Optimizar el helper correctamente ante cualquier peticion"}	2026-05-21 23:11:50.189733
727bf470-b945-409c-8d4c-dadb9b134f42	9d878b91-7650-4964-a565-4bd9d2999442	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Adaptar el contexto del helper a la localización del usuario"}	2026-05-21 23:11:50.819701
4fc6d588-a82b-45a4-a9a6-abd53d31f712	776db74d-634b-416e-9f2d-f90fded0094c	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Exportar sin credenciales"}	2026-05-21 23:11:51.614622
90262463-ac5e-4690-9b35-38ee29564438	408760a1-b486-4ed4-902c-3526233e9781	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Problema de redirección al crear una nueva oficina manual"}	2026-05-21 23:11:52.368042
88ac99d7-bce0-4e0c-bcab-23641f685d73	11771a27-830f-474e-85d2-8bdf0caabfdc	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Optimizacion del chat"}	2026-05-21 23:11:53.157835
09c37219-6b41-40a7-88f7-b5e45aba6b07	16cec1ae-42f9-4391-ab8e-93810a0bb976	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Adaptar el helpera a abierto por defecto"}	2026-05-21 23:11:53.828056
84e8dfcb-ce1e-4f15-8c9a-759a532a06f8	1c51a682-8978-41c8-9ab3-dbf6e5060131	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Salas de chat"}	2026-05-21 23:11:54.639803
83ddd2ae-841c-42d6-bb3e-40ffd33e382b	97514ebe-ee51-46f1-b655-d08a38232eff	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "En el chat global de oficinas hay que agregar el boton de cancelar cuando se manda mensaje"}	2026-05-21 23:11:55.271601
74165b0d-338d-469c-8974-c808d590f54c	99d9624b-b040-41c2-9cb9-f86db2f206f2	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Actualización de creación de la oficina"}	2026-05-21 23:11:55.990663
8a7abd09-8289-43db-a4de-23a0486717c0	a8631421-09bb-4906-8775-b6ded5daa3a0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Coordinar la funcionalidad del enjambre en el chat global"}	2026-05-21 23:11:56.672488
6a1a9c89-cdc5-4f04-a511-260eef9d98e7	448f036a-bdb8-46c3-8e6c-ea35d85ebb53	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Refactorizción del plan de creación de la oficina"}	2026-05-21 23:11:57.424557
179842ef-1e60-402c-aa4d-c973f7b936a2	822a4964-6538-4e1b-8a3e-88d618ed04ff	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "skills"}	2026-05-21 23:22:28.601325
14b8bd13-69ea-462b-affc-a81ecdfc52c1	8a9c77cc-e343-4e74-857a-557fb150cc9f	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "traits"}	2026-05-21 23:22:29.404435
eea0d67e-fb05-4990-98c7-831ec2ec06a9	1299f8cd-8569-4293-ba1e-dd55990b65e4	56f1614d-e66d-4d93-b090-33e03c34d084	comment_added	{"comment_id": "a7f36c90-128a-4c60-9b56-14234c58a645"}	2026-05-22 04:10:30.486697
a6cd548a-02c9-4f33-8449-3873a61263d6	1299f8cd-8569-4293-ba1e-dd55990b65e4	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "error", "from": "to_test"}	2026-05-22 04:10:41.944438
876539cf-75d8-4cf2-ae2f-0ab41949acb0	1299f8cd-8569-4293-ba1e-dd55990b65e4	56f1614d-e66d-4d93-b090-33e03c34d084	comment_added	{"comment_id": "eb9c36b1-b0aa-493d-8603-358d200806da"}	2026-05-22 04:24:00.475954
41cd73ab-e0b7-4d45-ad1f-2096d09408b3	4b639a7f-9d12-418b-b065-6467dde547e7	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Los comentarios deben poder editarse "}	2026-05-22 04:25:30.676467
3f415b15-19a1-4200-80c5-f1ec8bedd1b7	41a90fb7-18ae-4a98-9749-f93b033e1fb9	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Cuando le pase el maus por encima a una tarea de ser posible que se vean los comentarios "}	2026-05-22 04:26:02.307619
3b60eec2-8946-41b9-a2db-6749a21f6c42	727b4cc2-2b30-4a15-9c59-43453712727c	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Bug Premium de Carlitos"}	2026-05-22 04:37:16.099573
7ba8c16d-1923-4715-b5df-a110d4463294	9a81bde6-6e87-41b1-86ed-d111ccfb4e18	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "No se estan subiendo los documentos en el chat "}	2026-05-22 04:55:47.526926
ef0d52c8-59e3-4b5c-b99f-307c18014125	f2c84d5d-229d-4ee3-abdb-526272657aca	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"], "removed": []}	2026-05-22 05:05:24.008161
9794ec2e-c129-4e5e-8fbc-e7ff1ec12996	f2c84d5d-229d-4ee3-abdb-526272657aca	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": [], "removed": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"]}	2026-05-22 05:05:39.25654
b77629d1-3440-4cd2-9c07-30e372e08f91	f2c84d5d-229d-4ee3-abdb-526272657aca	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"], "removed": []}	2026-05-22 05:05:47.294219
442157da-4478-44ad-8509-500b1adf4338	4b639a7f-9d12-418b-b065-6467dde547e7	56f1614d-e66d-4d93-b090-33e03c34d084	assignees_changed	{"added": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"], "removed": []}	2026-05-22 05:14:54.81788
1f05f3ea-4fca-4c85-9cdd-0ac74caa1688	41a90fb7-18ae-4a98-9749-f93b033e1fb9	56f1614d-e66d-4d93-b090-33e03c34d084	assignees_changed	{"added": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"], "removed": []}	2026-05-22 05:14:59.943941
f4e47e6f-6e89-4838-b204-4d0136a27c46	4b639a7f-9d12-418b-b065-6467dde547e7	56f1614d-e66d-4d93-b090-33e03c34d084	assignees_changed	{"added": [], "removed": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"]}	2026-05-22 05:15:43.35372
a91613ea-4d1b-4ba9-b6c0-61f2fff8fefa	4b639a7f-9d12-418b-b065-6467dde547e7	56f1614d-e66d-4d93-b090-33e03c34d084	assignees_changed	{"added": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"], "removed": []}	2026-05-22 05:15:50.319742
8e7b033d-3554-43f7-a52d-55cde1b46e70	45637336-9b66-473d-9d81-37afe371a880	a9a0509e-c92a-4242-802b-f5136b06a5df	status_changed	{"to": "done", "from": "to_test"}	2026-05-22 08:14:55.341957
a2e31421-61b2-4e64-8c11-6d4bc90b4d58	3c757953-612e-4cde-a385-670c0da10e97	a9a0509e-c92a-4242-802b-f5136b06a5df	status_changed	{"to": "done", "from": "to_test"}	2026-05-22 08:14:58.679161
1058c4cf-24ee-4204-a9a9-6273ddd3126a	4b639a7f-9d12-418b-b065-6467dde547e7	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "043ccce3-7afb-401a-9be3-82ee7c980fd3"}	2026-05-22 13:42:35.067714
4ca162aa-d99e-4142-b6fd-99ea1c9bcd04	41a90fb7-18ae-4a98-9749-f93b033e1fb9	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "e5833f40-db40-404d-bdaa-65037ce61c24"}	2026-05-22 13:42:41.118621
534ba6b0-5dd9-4221-ba6b-98e86ac182a0	4b639a7f-9d12-418b-b065-6467dde547e7	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "todo"}	2026-05-22 13:42:41.557408
4d71925e-de4a-44f7-879a-17879ab3db88	41a90fb7-18ae-4a98-9749-f93b033e1fb9	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "todo"}	2026-05-22 13:42:42.101832
a2482b9e-816d-439d-bfc3-f2042a16a313	f719efdd-9051-47de-aba3-56b0c0b4605a	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Eliminar tokens MCP revocados"}	2026-05-22 13:57:10.955814
7a7c41ad-531e-4ddd-8332-07b3d7e66899	f719efdd-9051-47de-aba3-56b0c0b4605a	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "8121c9b1-0c98-49df-840d-09e09560f723"}	2026-05-22 14:00:39.396807
39a6f3fa-255f-4d64-8151-b3ec8a4809ea	f719efdd-9051-47de-aba3-56b0c0b4605a	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "todo"}	2026-05-22 14:00:40.246709
c539a1a7-ce72-436b-982a-44d101f24129	f2b7194c-b3a6-4190-80a7-08664ec51d48	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Agregar un color distinto cada estado y para cada prioridad "}	2026-05-22 14:03:05.972724
e183b2d6-6711-477f-a2f7-b1046895d443	f2b7194c-b3a6-4190-80a7-08664ec51d48	56f1614d-e66d-4d93-b090-33e03c34d084	priority_changed	{"to": "high", "from": "normal"}	2026-05-22 14:03:15.250499
a3fb0022-7f5a-40d4-87e9-95399b4bd927	f2b7194c-b3a6-4190-80a7-08664ec51d48	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "todo"}	2026-05-22 14:03:27.448588
dd47868d-20d0-444e-8759-290cb12b2269	f2b7194c-b3a6-4190-80a7-08664ec51d48	56f1614d-e66d-4d93-b090-33e03c34d084	priority_changed	{"to": "low", "from": "high"}	2026-05-22 14:03:27.448789
6569eb04-3b74-4fb0-8805-4d8b7f44328d	f2b7194c-b3a6-4190-80a7-08664ec51d48	56f1614d-e66d-4d93-b090-33e03c34d084	title_changed	{"to": "Agregar un color distinto a la targeta para cada estado ", "from": "Agregar un color distinto cada estado y para cada prioridad "}	2026-05-22 14:04:12.839044
7e554407-0206-4bed-8bd9-654fe09d9ed3	f2b7194c-b3a6-4190-80a7-08664ec51d48	56f1614d-e66d-4d93-b090-33e03c34d084	assignees_changed	{"added": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"], "removed": []}	2026-05-22 14:04:12.847257
b0b91e3a-ae37-4e9e-9f55-c15eead8babf	dd4efb77-96e3-4c92-a25d-f07063840cf4	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-22 14:05:36.380241
0fd56eb2-eb69-4688-b7bb-c0d75a0ec843	5a3865a9-9bc4-4fe7-b163-d2a931332bbc	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Permitir q el helper se cambie provider y modelo"}	2026-05-22 14:25:20.677495
36ac2c96-6afa-4e2e-ba16-acbde45f2ec0	9f5c8c81-e304-4874-986c-190a6aabc122	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Agregar Feedback de errores"}	2026-05-22 15:03:08.553481
2fff5d39-3d1e-422b-9548-d21bca233bb3	4d381c23-8cb6-450e-a53b-9ea0b7ee1e4e	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Skeleton load para todo"}	2026-05-22 16:29:44.970085
1271e8a6-8dd5-4114-bc52-fe9377720216	869780b2-daaa-4725-a93c-17a68a804827	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Lazy load de tareas"}	2026-05-22 16:29:58.313971
5ed39ab6-242c-4b9e-9ee2-15c37d4014ae	46205602-5317-4bd4-8f0b-2ccc9b7286b7	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "error"}	2026-05-22 19:44:06.469347
8ee7f112-ff6d-48bd-99bd-5517bf186976	46205602-5317-4bd4-8f0b-2ccc9b7286b7	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"], "removed": []}	2026-05-22 19:44:06.479997
024795a2-88c3-49a1-abee-d247767dfb32	a06d86c0-8b36-4a64-be44-0afe77da49f6	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "2414e333-fc06-4fdd-9a02-e816954b0fd3"}	2026-05-22 19:45:45.565632
5dc566b0-1b07-4d85-826a-d60203c87575	a06d86c0-8b36-4a64-be44-0afe77da49f6	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "not_started"}	2026-05-22 19:45:50.031691
a19a41e8-f33e-4dfc-a9dc-889660ee44e9	8878cc8d-6e8a-42aa-9c1c-206deceab9ed	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "error"}	2026-05-23 02:13:12.391002
2d3d26ef-b142-4f38-acec-8da129500f97	369dba62-8298-4e4e-91e7-8aebd12e54a5	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "error"}	2026-05-23 02:13:12.671407
2933dde3-c185-426f-9f5d-8d35546c80aa	742de7b0-1520-4a71-8a56-87c35d321843	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "error"}	2026-05-23 02:13:12.979676
47818068-27fe-424a-997e-60cf54b729d8	b8b17bfa-18e2-4607-9b98-fe44ea8ac118	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "error"}	2026-05-23 02:13:13.362664
1133bb2e-83ae-4871-8ff9-6b39f125c397	1299f8cd-8569-4293-ba1e-dd55990b65e4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "error"}	2026-05-23 02:13:13.678138
73b73be0-e409-4d07-a234-7b94b387ef87	9a81bde6-6e87-41b1-86ed-d111ccfb4e18	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "error"}	2026-05-23 02:14:48.289075
25211768-bbfc-40b4-9626-e10e90b48727	9a81bde6-6e87-41b1-86ed-d111ccfb4e18	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": ["56f1614d-e66d-4d93-b090-33e03c34d084"], "removed": []}	2026-05-23 02:14:48.299012
9744fe84-c1bf-45de-ac79-514e89e0dea5	ff5949f5-9a58-41d9-a7d8-dfec2e0be590	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "error"}	2026-05-23 02:14:49.992578
affab4f8-5272-436d-a5ec-0de628ab23f0	ff5949f5-9a58-41d9-a7d8-dfec2e0be590	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": ["56f1614d-e66d-4d93-b090-33e03c34d084"], "removed": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"]}	2026-05-23 02:14:50.006143
c3072584-a663-4931-94d2-a7af32cfbc18	8878cc8d-6e8a-42aa-9c1c-206deceab9ed	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "9615556a-28e3-4af7-9cf5-c240569a9fbc"}	2026-05-23 02:16:06.773068
89d06ef2-0404-4a85-919e-671b5f3c0386	369dba62-8298-4e4e-91e7-8aebd12e54a5	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "8c4cd0b5-2ec2-40fd-8a5a-e7f2fc279f4d"}	2026-05-23 02:16:10.205792
839a8812-c3b4-45ce-b411-f6d1d1e17ce1	742de7b0-1520-4a71-8a56-87c35d321843	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "eaf7d648-b1a2-4cf9-99cd-1677493ad286"}	2026-05-23 02:16:13.16563
f68238f0-4b3c-4bce-adff-4977bb2bf6f0	b8b17bfa-18e2-4607-9b98-fe44ea8ac118	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "d9463c7e-22a5-482c-94a4-b78177870e1d"}	2026-05-23 02:16:19.893134
e590a806-41a4-4e62-ba5d-edfcb2a83600	1299f8cd-8569-4293-ba1e-dd55990b65e4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "5d50d30f-00e3-4165-81d7-e7980d2507c9"}	2026-05-23 02:16:24.050546
839ffbc5-a493-4f92-8c25-4f99a471589e	9a81bde6-6e87-41b1-86ed-d111ccfb4e18	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "eae3010e-50b3-4cb5-b2e0-73e151711880"}	2026-05-23 02:17:20.65113
574cbed0-b5cf-4936-94dc-f1b84d1d2ceb	ff5949f5-9a58-41d9-a7d8-dfec2e0be590	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "90c98cdb-7a81-462e-a949-0ac5f2c761ee"}	2026-05-23 02:17:25.678042
b4c1b44f-8fbc-4c91-9451-db1242aae13c	9a81bde6-6e87-41b1-86ed-d111ccfb4e18	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "error", "from": "to_test"}	2026-05-23 02:17:46.959199
7fa95e27-d39f-4c50-91ff-6d6d41c707ef	ff5949f5-9a58-41d9-a7d8-dfec2e0be590	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "error", "from": "to_test"}	2026-05-23 02:17:47.247165
e2436810-0a29-410d-931a-6d3fe8d2e352	9a81bde6-6e87-41b1-86ed-d111ccfb4e18	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": [], "removed": ["56f1614d-e66d-4d93-b090-33e03c34d084"]}	2026-05-23 02:18:09.528188
eb902b4c-4871-472c-bf91-8b3f44601f55	ff5949f5-9a58-41d9-a7d8-dfec2e0be590	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": [], "removed": ["56f1614d-e66d-4d93-b090-33e03c34d084"]}	2026-05-23 02:18:09.824288
fb56c07a-6f79-4699-b263-c00dbe20542f	9a81bde6-6e87-41b1-86ed-d111ccfb4e18	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "to_test", "from": "error"}	2026-05-23 04:46:02.902019
93ed472f-472f-4d46-9f73-6a6530312c58	8878cc8d-6e8a-42aa-9c1c-206deceab9ed	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-23 04:51:38.909062
88abeac1-0ea5-4043-b84b-73072b1fdf53	369dba62-8298-4e4e-91e7-8aebd12e54a5	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "to_test"}	2026-05-23 05:10:31.153431
8242ee5d-d8a4-4497-8408-d6b7dc57029e	742de7b0-1520-4a71-8a56-87c35d321843	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "to_test"}	2026-05-23 05:10:31.946711
4b5b4a47-ed78-4d0f-8e93-9208bbbbdc27	ff5949f5-9a58-41d9-a7d8-dfec2e0be590	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "error"}	2026-05-23 05:10:32.235337
1d83fd10-7e00-4eb3-bf76-f74f6302b82e	9a81bde6-6e87-41b1-86ed-d111ccfb4e18	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": ["56f1614d-e66d-4d93-b090-33e03c34d084"], "removed": []}	2026-05-23 05:12:35.943625
71be536c-cbf9-4ffb-bcf1-bf170518d490	b8b17bfa-18e2-4607-9b98-fe44ea8ac118	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": ["56f1614d-e66d-4d93-b090-33e03c34d084"], "removed": []}	2026-05-23 05:12:51.738049
f7f47d69-6080-4123-8a4a-1b30ebefea79	9bcb6921-1825-438e-8384-4d313738f48c	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Agentes conectados a wsapp solicitan el numero de telefono para enviar un mensaje "}	2026-05-23 05:20:31.519266
fc9dd06e-3379-42f1-82a9-237eca162a5b	4d381c23-8cb6-450e-a53b-9ea0b7ee1e4e	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "todo"}	2026-05-23 23:51:53.523553
7c25ac7e-bc40-489d-b3dc-bae056543054	869780b2-daaa-4725-a93c-17a68a804827	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "todo"}	2026-05-23 23:51:53.957566
abc64dca-1859-4bf6-9eb7-69211fe58468	4d381c23-8cb6-450e-a53b-9ea0b7ee1e4e	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "e428fbcf-158e-4e48-ad9a-89cdac032160"}	2026-05-23 23:51:57.117979
7022871b-9264-4907-b8d3-75ed7d4c8586	869780b2-daaa-4725-a93c-17a68a804827	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "0bbb5b16-2c46-4e78-be03-c84f098d4dd1"}	2026-05-23 23:52:01.238122
049ae60a-5959-4c92-ae8c-10db575463e7	3468f343-484e-46da-b73c-3a369a75349c	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Que se pueda compactar y descompletar cada sesión en la vista de lista "}	2026-05-24 00:57:44.082811
2ff17254-2998-4c96-8797-5f203a1dfd96	8b74cc5e-1710-4d34-a6c4-13b56fcf7b51	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Boton de agentes en base de conocimiento no funciona "}	2026-05-24 01:17:48.826409
bb705913-70d6-4b98-96c4-e07a991f3b3e	fcddd162-7eb6-46e0-be62-3ca4d2c1d15c	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Editar agente falla al deseleccionar una base de conocimiento"}	2026-05-24 01:18:21.698838
5e9c7014-bd85-41b0-aef9-a908213042a9	8b74cc5e-1710-4d34-a6c4-13b56fcf7b51	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "error", "from": "not_started"}	2026-05-24 02:21:09.67877
5b7c9af0-26f0-42c1-804a-76cb707466b3	fcddd162-7eb6-46e0-be62-3ca4d2c1d15c	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "error", "from": "not_started"}	2026-05-24 02:21:20.332111
a8b6c7f9-b85e-47b1-a414-f382a192e7f9	02508451-ff21-4883-bbf2-dc0ef63f7388	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "not_started"}	2026-05-24 02:21:48.413322
49461860-53ad-40c3-bf84-5ce422f6a240	f0dbb3e1-f966-44bc-a31d-8bbaa3a4c66d	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "error", "from": "not_started"}	2026-05-24 02:22:00.993099
0b1d6538-8cc6-4280-8267-26152b80a713	c7344611-467a-461c-ab4f-65d0fec690ad	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Tools de channels no se exponen al agente en su chat directo"}	2026-05-24 02:42:58.215958
6ef9972f-f70f-4f31-aff7-bd58e1f7fba5	e6e639c5-0ff5-42f7-aaaf-bbb0e93cf63e	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-24 02:48:44.594018
5216fd5c-1000-4302-b13d-66e9396fc504	9e97d043-30b6-4f1f-88f6-cf62883f8933	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-24 02:49:04.143987
b48f8a09-3b3f-423f-96b8-b01683e3ce95	6b9d3b05-11d8-4e21-8ff7-04c3f015140c	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Refactorización de los MCP"}	2026-05-24 03:11:18.719687
9351e1d0-4a3b-4741-b620-5830daf52ce9	cf087882-5016-4a89-a610-a98a72a79417	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-24 03:14:58.369019
e6711632-3496-4b9e-b23b-26bc1551eef1	6edd2329-5f48-4c33-b920-47707d528f72	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Hay un despagine en la comprención de rutas de los agentes "}	2026-05-24 03:21:11.891736
24d18e1b-413c-4e39-9ae9-8b20abb76757	f76a30ef-033d-411f-8956-ffae22f8de50	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Agregar visor de imagenes en tadiin "}	2026-05-24 03:36:50.910098
42970f72-981d-43df-8f82-b31124782f0d	9a81bde6-6e87-41b1-86ed-d111ccfb4e18	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-24 03:37:11.142531
934b1bd5-9655-40bd-be16-d43e695f9322	6363e67d-12e2-4749-a2b1-20ac454f6812	56f1614d-e66d-4d93-b090-33e03c34d084	comment_added	{"comment_id": "33d6f763-c8d4-4400-a22f-54f1e89714fe"}	2026-05-24 03:37:50.984077
2f1a7342-e449-437f-beef-7552c473f724	b8b17bfa-18e2-4607-9b98-fe44ea8ac118	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-24 04:06:25.538569
ab79b0fe-5797-411f-8580-f281035362e9	02508451-ff21-4883-bbf2-dc0ef63f7388	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-24 04:10:38.140638
9bc10416-f086-4f45-8e9e-e2d902c026e6	f0dbb3e1-f966-44bc-a31d-8bbaa3a4c66d	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "to_test", "from": "error"}	2026-05-24 18:30:25.484134
4a5a3d3d-9ce8-4012-b488-c86601c2e519	f0dbb3e1-f966-44bc-a31d-8bbaa3a4c66d	56f1614d-e66d-4d93-b090-33e03c34d084	assignees_changed	{"added": ["56f1614d-e66d-4d93-b090-33e03c34d084"], "removed": []}	2026-05-24 18:30:25.522957
dc8d680a-b9ec-4809-9e00-3d21a3dec103	8b74cc5e-1710-4d34-a6c4-13b56fcf7b51	56f1614d-e66d-4d93-b090-33e03c34d084	assignees_changed	{"added": ["56f1614d-e66d-4d93-b090-33e03c34d084"], "removed": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"]}	2026-05-24 18:30:34.885009
baf134b6-4c28-49af-9313-df60774a7a7f	fcddd162-7eb6-46e0-be62-3ca4d2c1d15c	56f1614d-e66d-4d93-b090-33e03c34d084	assignees_changed	{"added": ["56f1614d-e66d-4d93-b090-33e03c34d084"], "removed": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"]}	2026-05-24 18:41:18.433658
e7b99a39-2d41-4a1b-a427-e9076d528eaa	c7344611-467a-461c-ab4f-65d0fec690ad	fc7a4bb9-6b76-4db2-9a18-0916159aa890	assignees_changed	{"added": ["fc7a4bb9-6b76-4db2-9a18-0916159aa890"], "removed": []}	2026-05-24 21:41:31.866179
4dc51823-41bf-4c63-93d7-2d38d43dd2ed	8b74cc5e-1710-4d34-a6c4-13b56fcf7b51	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "to_test", "from": "error"}	2026-05-24 22:29:02.054197
719c4d0d-f917-4410-8427-a40c616d881a	fcddd162-7eb6-46e0-be62-3ca4d2c1d15c	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "to_test", "from": "error"}	2026-05-24 22:29:17.658522
d192a4e6-dcaa-4316-9616-f9ba35480c67	6b0bc0a8-50bc-4842-86ec-c339a33ce819	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "backlog", "from": "in_progress"}	2026-05-24 22:33:35.460291
f0506ec7-1e96-405e-8586-3fa6df77f140	9bcb6921-1825-438e-8384-4d313738f48c	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "error"}	2026-05-25 03:48:57.510867
86396c34-6b27-4d68-b4fe-ed2bfb0f6755	c7344611-467a-461c-ab4f-65d0fec690ad	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "error"}	2026-05-25 03:49:05.081392
1f94a796-c1d9-4062-92f5-cdb0cee528ae	3b29ae36-c2d1-4c5a-a5ba-419a67bdb080	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "to_test", "from": "not_started"}	2026-05-25 04:26:25.614593
85100f2c-1a73-4c7c-bd20-9d0824c25f67	b4f552a5-67e0-4b24-98c6-89ae7250d3eb	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Reconectar canal de WhatsApp - \\"Not connected\\" tras 93 intentos"}	2026-05-25 06:23:39.397894
707d608f-4e13-4b2a-916a-7e73e1afa266	ad5ca941-76c5-4c73-9004-473b9eb0c2c9	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "🎃🎄 Chiste malo del día (para Hal/Halexy)"}	2026-05-25 11:21:55.967195
6528009c-44a9-419f-8a2c-0dde178d6301	3468f343-484e-46da-b73c-3a369a75349c	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "todo"}	2026-05-25 14:13:56.164588
58df4c51-6272-4f27-b00f-4ee92404ca6f	3468f343-484e-46da-b73c-3a369a75349c	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "75d4daf1-2b0b-4065-a606-01a594bd61ea"}	2026-05-25 14:13:57.983082
f4ea26d8-2ce8-447f-aca4-30b1230a220b	0bf4fe43-2a5c-4fa7-8d1f-c3f53e989c25	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Tap en notificación FCM no abría la APK"}	2026-05-25 14:18:04.585171
e7b2f296-69ce-4147-a338-888b2e16c735	0bf4fe43-2a5c-4fa7-8d1f-c3f53e989c25	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "416186c8-a5b3-4661-860b-f9f489234b8f"}	2026-05-25 14:18:14.162597
1dcf2cb4-0672-46fb-9a1a-49ce99f943c3	1699e40d-763d-46ce-a0b8-7c8bcfa46b75	fc7a4bb9-6b76-4db2-9a18-0916159aa890	created	{"title": "Hacer q el helper tenga conocimiento de q existen bases de conocimiento y q el builder pueda crearlas y subir las bases"}	2026-05-25 14:40:44.39085
5f0aa6d9-93ed-4a11-a4dc-ceb89789b564	1699e40d-763d-46ce-a0b8-7c8bcfa46b75	fc7a4bb9-6b76-4db2-9a18-0916159aa890	priority_changed	{"to": "urgent", "from": "normal"}	2026-05-25 14:40:53.604816
9e81a40a-c8ac-4da7-83cc-069ecdebc15f	9bcb6921-1825-438e-8384-4d313738f48c	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-27 03:00:47.240077
f499b339-7cb3-4c2b-803d-5b671d29dbca	95a74ca6-1121-4053-a4f9-40c130a0e498	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "El canal de wsapp se cae tras el el agente enviar un mensaje directo a un usuario"}	2026-05-27 03:03:22.072783
21d361eb-f903-455d-afc8-6f468b804dc4	f0dbb3e1-f966-44bc-a31d-8bbaa3a4c66d	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-27 03:21:39.719046
d3945d93-4a0b-4d28-b942-07db29256073	8b74cc5e-1710-4d34-a6c4-13b56fcf7b51	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-27 03:24:09.770012
158e7700-8e35-4943-ade8-51b601f67724	fcddd162-7eb6-46e0-be62-3ca4d2c1d15c	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-27 03:31:09.521144
35e9fe47-5edc-4ef8-9256-ab0437d7e8f2	05fd5ea9-a126-4385-b25c-8f13d489a387	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Lograr que los tres lugares desde los que se puede asignar bases de conocimiento a los agentes sen un solo systema"}	2026-05-27 03:37:51.916773
3e8b587a-8741-4cbe-a899-1b0527bb03cd	c7344611-467a-461c-ab4f-65d0fec690ad	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "to_test"}	2026-05-27 03:38:13.656237
ac3749e3-81a6-4d5b-983c-e6284eef33a1	3b29ae36-c2d1-4c5a-a5ba-419a67bdb080	56f1614d-e66d-4d93-b090-33e03c34d084	comment_added	{"comment_id": "10feadc4-eb68-486c-bf0f-93d0217ea31e"}	2026-05-27 04:52:47.501136
b4f14888-903a-47d2-865c-a7afadc8dd25	3b29ae36-c2d1-4c5a-a5ba-419a67bdb080	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "standby", "from": "to_test"}	2026-05-27 04:53:02.627093
ec9707d0-925d-4734-805f-83f4315ad897	b4f552a5-67e0-4b24-98c6-89ae7250d3eb	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "error"}	2026-05-27 17:59:03.080885
383d3420-aecc-48f6-9fdf-c15928cb4d77	95a74ca6-1121-4053-a4f9-40c130a0e498	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "done", "from": "error"}	2026-05-27 17:59:11.821155
2a53fcce-108f-4e13-be2d-9b9aac6b819c	05fd5ea9-a126-4385-b25c-8f13d489a387	56f1614d-e66d-4d93-b090-33e03c34d084	status_changed	{"to": "to_test", "from": "error"}	2026-05-27 18:32:12.653116
46aea371-6167-492c-baf9-b7771bb6c70b	10f95d2d-8750-42ac-a745-0a1e323bfa1d	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Mensajes en el chat se desorganizan al salir y volver a entrar al chat de la oficina "}	2026-05-29 03:49:49.514304
2ad504c4-84b7-4da5-8f3a-4d403f128070	9cf5e4c7-ad23-405d-b75b-263dcab86263	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Bitacora"}	2026-05-29 03:50:39.640682
af7e4667-2a3f-4a83-be62-29b259f56557	61bc33ec-a755-46a5-832b-0e69fa7e88b8	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "EL helper no edita bien los agentes "}	2026-05-29 15:18:58.883206
1eb68f00-d4c8-4126-ad1e-e0e55210bd4d	61bc33ec-a755-46a5-832b-0e69fa7e88b8	56f1614d-e66d-4d93-b090-33e03c34d084	properties_changed	{"changes": {"tadin_project": {"to": ["Frontend", "Backend"], "from": null}}}	2026-05-30 05:08:11.309878
c239ae2d-c56a-4682-9c58-936f740abb47	727b4cc2-2b30-4a15-9c59-43453712727c	a9a0509e-c92a-4242-802b-f5136b06a5df	status_changed	{"to": "to_test", "from": "not_started"}	2026-05-30 05:09:05.111485
76a6b65a-6054-492a-8c4f-5f114471f645	9cf5e4c7-ad23-405d-b75b-263dcab86263	a9a0509e-c92a-4242-802b-f5136b06a5df	status_changed	{"to": "done", "from": "not_started"}	2026-05-30 05:10:34.319182
508d084a-d78b-4156-acb4-29c3e11ac9bf	0e384b18-27fa-4d4c-bcd4-212cb334f5e9	56f1614d-e66d-4d93-b090-33e03c34d084	created	{"title": "Copia los filtros de notion y que se pueda limpiar los filtros con un boton "}	2026-05-30 05:30:02.055156
a2a573a5-71ca-44d0-b5d5-d557356b9a53	0e384b18-27fa-4d4c-bcd4-212cb334f5e9	fc7a4bb9-6b76-4db2-9a18-0916159aa890	status_changed	{"to": "done", "from": "todo"}	2026-05-31 05:59:40.482483
8f3c5655-335b-4433-883c-59a1af1ad62b	0e384b18-27fa-4d4c-bcd4-212cb334f5e9	fc7a4bb9-6b76-4db2-9a18-0916159aa890	comment_added	{"comment_id": "ecf3a600-6097-4108-b09f-bd60ce8030a7"}	2026-05-31 05:59:50.486768
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.alembic_version (version_num) FROM stdin;
0009
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.app_settings (key, value) FROM stdin;
last_notified_app_version	0.2.7
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.comments (id, task_id, author_id, body, created_at, updated_at) FROM stdin;
a7f36c90-128a-4c60-9b56-14234c58a645	1299f8cd-8569-4293-ba1e-dd55990b65e4	56f1614d-e66d-4d93-b090-33e03c34d084	A la hora de editar agentes , cambiarles la credencial el builder falla	2026-05-22 04:10:30.486012	2026-05-22 04:10:30.486032
eb9c36b1-b0aa-493d-8603-358d200806da	1299f8cd-8569-4293-ba1e-dd55990b65e4	56f1614d-e66d-4d93-b090-33e03c34d084	revisado de nuevo parese cer un problema con la herramienta o con el promt , hay que verificar que no tenga una herramienta duplicada	2026-05-22 04:24:00.475652	2026-05-22 04:24:00.47567
eae3010e-50b3-4cb5-b2e0-73e151711880	9a81bde6-6e87-41b1-86ed-d111ccfb4e18	fc7a4bb9-6b76-4db2-9a18-0916159aa890	**Problema:** Los documentos adjuntados en el chat no se están subiendo correctamente.\n\n**Investigación:** No se pudo reproducir vía API. Posible race condition donde `currentSessionId` es `null` en el momento en que se intenta subir el archivo, antes de que la sesión esté inicializada. También puede estar relacionado con validación en `_safe_name` que rechaza ciertos nombres de archivo.\n\n**Pendiente para reproducir:**\n- Confirmar si ocurre siempre o solo en la primera subida de una sesión nueva\n- Verificar si el error llega al backend o se corta antes en el frontend\n- Revisar `chat_documents.py` y el flujo de inicialización de sesión en `Chat.jsx`\n\n**Archivos relevantes:**\n- `tadin-service/src/app/api/v1/chat_documents.py`\n- `tadin-app/src/components/Chat/Chat.jsx`	2026-05-23 02:17:20.650851	2026-05-23 02:17:20.650868
043ccce3-7afb-401a-9be3-82ee7c980fd3	4b639a7f-9d12-418b-b065-6467dde547e7	fc7a4bb9-6b76-4db2-9a18-0916159aa890	✅ **Implementado** por Claude vía MCP.\n\nEn el modal de tarea → tab **Comentarios**, cada comentario tuyo ahora muestra dos botones:\n- **Editar** (azul) → entra en modo edición inline con textarea + Guardar/Cancelar\n- **Eliminar** (rojo) → confirma y borra\n\nCuando un comentario ha sido editado, aparece *"(editado)"* junto a la fecha.\n\nSolo el autor puede editar/eliminar sus comentarios (validado en backend).	2026-05-22 13:42:35.067414	2026-05-22 13:42:35.067433
e5833f40-db40-404d-bdaa-65037ce61c24	41a90fb7-18ae-4a98-9749-f93b033e1fb9	fc7a4bb9-6b76-4db2-9a18-0916159aa890	✅ **Implementado** por Claude vía MCP.\n\nComponente nuevo: `CommentsHoverPreview`. Al hacer **hover sobre una tarjeta** que tenga comentarios (cualquier vista: kanban, lista, etc.), aparece un popup pequeño con:\n- Los últimos 3 comentarios (avatar + nombre + cuerpo en markdown truncado a 2 líneas)\n- Indicador *"y N más…"* si hay más\n\nDetalles:\n- **Lazy load**: solo fetcha cuando el hover dura más de 300ms (evita spam al pasar el ratón)\n- Se cachea por sesión del componente\n- **No aparece en móvil** (no hay hover en touch — para ver comentarios se abre la tarea)\n- Se posiciona automáticamente arriba o abajo según el espacio disponible\n\nLas tarjetas sin comentarios (la mayoría) no muestran nada — sin overhead visual.	2026-05-22 13:42:41.118261	2026-05-22 13:42:41.118322
8121c9b1-0c98-49df-840d-09e09560f723	f719efdd-9051-47de-aba3-56b0c0b4605a	fc7a4bb9-6b76-4db2-9a18-0916159aa890	✅ **Implementado** por Claude vía MCP.\n\n**Cambio**: ahora "Revocar" hace **hard-delete** del token (antes dejaba la fila con `revoked_at` y aparecía como "revocado" en la UI — ruido visual permanente).\n\n- Backend `DELETE /mcp-tokens/{id}` → `session.delete(row)` real\n- Frontend `Settings.tsx`: al revocar, el token desaparece de la lista al instante\n- **Cleanup**: borrados 11 tokens que estaban revocados de pruebas anteriores\n\nJustificación: el token plaintext sólo se muestra una vez al crear, así que un token revocado no se puede recuperar ni usar — guardarlo sólo añadía ruido.	2026-05-22 14:00:39.396432	2026-05-22 14:00:39.396454
2414e333-fc06-4fdd-9a02-e816954b0fd3	a06d86c0-8b36-4a64-be44-0afe77da49f6	fc7a4bb9-6b76-4db2-9a18-0916159aa890	Algunos modelos no soportan tools	2026-05-22 19:45:45.565196	2026-05-22 19:45:45.565225
9615556a-28e3-4af7-9cf5-c240569a9fbc	8878cc8d-6e8a-42aa-9c1c-206deceab9ed	fc7a4bb9-6b76-4db2-9a18-0916159aa890	**Problema:** La función `_ps()` que parsea la lista blanca/negra esperaba un `string`, pero el componente `channel_multiselect` del builder enviaba un `array` cuando se seleccionaba un contacto haciendo click. Esto causaba un `AttributeError: 'list' object has no attribute 'strip'` al intentar conectar el canal.\n\n**Fix:** Se modificó `_ps()` para aceptar tanto `list` como `str`.\n\n**Archivos modificados:**\n- `~/.tadin/integrations/whatsapp-channel.py`\n- `tadin-files/channels/whatsapp_channel.py`\n\n**Cómo testear:** Crear una instancia de wsapp desde el builder, agregar contactos a la lista blanca/negra haciendo click (no manual), guardar y conectar. No debe lanzar error.	2026-05-23 02:16:06.772416	2026-05-23 02:16:06.772442
8c4cd0b5-2ec2-40fd-8a5a-e7f2fc279f4d	369dba62-8298-4e4e-91e7-8aebd12e54a5	fc7a4bb9-6b76-4db2-9a18-0916159aa890	**Problema:** La función `_ps()` que parsea la lista blanca esperaba un `string`, pero al agregar un contacto haciendo click el UI enviaba un `array`. Esto causaba `AttributeError: 'list' object has no attribute 'strip'` al conectar el canal.\n\n**Fix:** Se modificó `_ps()` para aceptar tanto `list` como `str`.\n\n**Archivos modificados:**\n- `~/.tadin/integrations/whatsapp-channel.py`\n- `tadin-files/channels/whatsapp_channel.py`\n\n**Cómo testear:** Configurar wsapp con contactos en lista blanca agregados haciendo click, conectar y verificar que filtra correctamente.	2026-05-23 02:16:10.205518	2026-05-23 02:16:10.205535
eaf7d648-b1a2-4cf9-99cd-1677493ad286	742de7b0-1520-4a71-8a56-87c35d321843	fc7a4bb9-6b76-4db2-9a18-0916159aa890	**Problema:** La función `_ps()` que parsea la lista blanca esperaba un `string`, pero al agregar un contacto haciendo click el UI enviaba un `array`. Esto causaba `AttributeError: 'list' object has no attribute 'strip'` al conectar el canal.\n\n**Fix:** Se modificó `_ps()` para aceptar tanto `list` como `str`.\n\n**Archivos modificados:**\n- `~/.tadin/integrations/whatsapp-channel.py`\n- `tadin-files/channels/whatsapp_channel.py`\n\n**Cómo testear:** Configurar wsapp con contactos en lista blanca agregados haciendo click, conectar y verificar que filtra correctamente.	2026-05-23 02:16:13.165358	2026-05-23 02:16:13.165385
d9463c7e-22a5-482c-94a4-b78177870e1d	b8b17bfa-18e2-4607-9b98-fe44ea8ac118	fc7a4bb9-6b76-4db2-9a18-0916159aa890	**Problema:** `_mask_secrets()` eliminaba completamente el campo `bot_token` de la respuesta API. El frontend recibía `undefined`, dejaba el campo vacío, y la validación `required` bloqueaba el botón de guardar.\n\n**Fix (3 partes):**\n1. Backend `_mask_secrets()`: devuelve `"***"` en vez de eliminar la key.\n2. Backend `_strip_masked_secrets()`: si llega `"***"` o vacío, no sobreescribe el token en DB; si llega un valor real nuevo, sí lo actualiza.\n3. Frontend `IntegrationConfigModal.jsx`: inicializa el campo con `"***"` en vez de ignorarlo, así el botón de guardar queda habilitado.\n\n**Archivos modificados:**\n- `tadin-service/src/app/api/v1/channels.py`\n- `tadin-app/src/components/Integrations/IntegrationConfigModal.jsx`\n\n**Cómo testear:** Abrir una instancia de Telegram existente → el campo token debe mostrar `***` y el botón guardar estar activo. Guardar sin cambiar el token → debe seguir funcionando con el token original. Cambiar el token por uno nuevo → debe actualizarse.	2026-05-23 02:16:19.892706	2026-05-23 02:16:19.892729
5d50d30f-00e3-4165-81d7-e7980d2507c9	1299f8cd-8569-4293-ba1e-dd55990b65e4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	**Problema:** El `useEffect` del builder que carga las API keys del proveedor seleccionado no auto-seleccionaba la key cuando solo había una disponible. El usuario tenía que seleccionarla manualmente.\n\n**Fix:** Se agregó lógica en el `useEffect`: si no hay key seleccionada y el proveedor tiene exactamente 1 key disponible, se auto-selecciona.\n\n**Archivo modificado:**\n- `tadin-app/src/components/Builder/AgentBuilderModal.jsx`\n\n**Cómo testear:** Abrir el builder de agentes, seleccionar un proveedor LLM que tenga una sola API key configurada → debe auto-seleccionarse sin intervención del usuario.	2026-05-23 02:16:24.049973	2026-05-23 02:16:24.049993
90c98cdb-7a81-462e-a949-0ac5f2c761ee	ff5949f5-9a58-41d9-a7d8-dfec2e0be590	fc7a4bb9-6b76-4db2-9a18-0916159aa890	**Problema:** Los agentes conectados a wsapp no pueden enviar imágenes. Desde wsapp dicen que no pueden; desde Tadin piden número de teléfono en vez de enviar directo.\n\n**Investigación:** No se pudo reproducir porque requiere una instancia wsapp con QR escaneado y conectada. El canal existe pero no hay sesión activa disponible para testear.\n\n**Pendiente para reproducir:**\n- Necesita instancia wsapp con QR conectado\n- Verificar el tool `send_image` / `deliver_file` en `whatsapp-channel.py` — revisar si está implementado y si el agente tiene acceso a ese tool\n- Verificar si el agente recibe el tool en su lista de herramientas disponibles\n\n**Archivos relevantes:**\n- `~/.tadin/integrations/whatsapp-channel.py`\n- `tadin-files/channels/whatsapp_channel.py`	2026-05-23 02:17:25.677706	2026-05-23 02:17:25.677731
e428fbcf-158e-4e48-ad9a-89cdac032160	4d381c23-8cb6-450e-a53b-9ea0b7ee1e4e	fc7a4bb9-6b76-4db2-9a18-0916159aa890	Implementado en v0.2.3: nuevo componente `Skeleton` + variantes `SkeletonCard`, `SkeletonList`, `SkeletonKanban`. Sustituye "Cargando…" en `App.tsx` (splash inicial), `ProjectView` (skeleton kanban completo mientras carga el proyecto), `ProjectFeedback`, `Projects` (3 cards placeholder), `TaskModal` (comentarios + activity), `CommentsHoverPreview`.	2026-05-23 23:51:57.117615	2026-05-23 23:51:57.117634
0bbb5b16-2c46-4e78-be03-c84f098d4dd1	869780b2-daaa-4725-a93c-17a68a804827	fc7a4bb9-6b76-4db2-9a18-0916159aa890	Implementado en v0.2.3. Backend `GET /tasks` ahora acepta `?limit` y `?offset`; cuando se pasa `limit` devuelve `X-Total-Count` para saber cuánto falta (CORS expuesto). Frontend: nuevo `api.listTasksPage()` + `loadTasksProgressively()` en `ProjectView` que pide la 1ª página de 100, renderiza al instante y luego va appendeando lotes de 100 hasta agotar. Si el endpoint paginado falla, fallback al `listTasks` no paginado. Dedupe por id para evitar dobles renders si llega un evento SSE durante la carga.	2026-05-23 23:52:01.237737	2026-05-23 23:52:01.237772
75d4daf1-2b0b-4065-a606-01a594bd61ea	3468f343-484e-46da-b73c-3a369a75349c	fc7a4bb9-6b76-4db2-9a18-0916159aa890	Implementado en v0.2.5. Cada sección de estado en `ListView` ahora tiene caret ▾/▸ y es clickable para colapsar/expandir. Estado persistido en `localStorage` por proyecto (`tareapp_list_collapsed_<projectId>`). Botón extra arriba a la derecha "Colapsar todo / Expandir todo" para alternar todos los grupos a la vez.	2026-05-25 14:13:57.982581	2026-05-25 14:13:57.982607
416186c8-a5b3-4661-860b-f9f489234b8f	0bf4fe43-2a5c-4fa7-8d1f-c3f53e989c25	fc7a4bb9-6b76-4db2-9a18-0916159aa890	Fix v0.2.6:\n- `backend/app/fcm.py`: quitado `click_action`. Sin ese campo, FCM lanza la Activity launcher (MainActivity) por defecto → Capacitor dispara `pushNotificationActionPerformed`.\n- `frontend/src/lib/usePushNotifications.ts`: el listener antes solo navegaba si había `project_id`. Ahora rutea por `data.kind`:\n  - `app.update` → `nav("/")` para que se vea el banner de descarga.\n  - `task_id`/`project_id` → al proyecto correspondiente.\n  - fallback → `nav("/")`.	2026-05-25 14:18:14.162092	2026-05-25 14:18:14.162112
10feadc4-eb68-486c-bf0f-93d0217ea31e	3b29ae36-c2d1-4c5a-a5ba-419a67bdb080	56f1614d-e66d-4d93-b090-33e03c34d084	Cuando falla el flujo el manager deberia ser capaz de preguntar si quieres que revises si se puede arreglar o intentar arreglarlo el solo	2026-05-27 04:52:47.500475	2026-05-27 04:52:47.500719
33d6f763-c8d4-4400-a22f-54f1e89714fe	6363e67d-12e2-4749-a2b1-20ac454f6812	56f1614d-e66d-4d93-b090-33e03c34d084	No se como verificar si esto esta funcionando bien	2026-05-24 03:37:50.983763	2026-05-27 04:53:24.992847
ecf3a600-6097-4108-b09f-bd60ce8030a7	0e384b18-27fa-4d4c-bcd4-212cb334f5e9	fc7a4bb9-6b76-4db2-9a18-0916159aa890	Implementado en v0.2.7. Sistema completo Notion-style:\n\n**Nuevos archivos**\n- `frontend/src/lib/filters.ts` — tipos `TaskFilter`, motor `filterTasks()` puro client-side, metadata de operadores por tipo, migrador de saved-filters legacy (search/assignee_filter → TaskFilter[]).\n- `frontend/src/components/FilterBar.tsx` — chips horizontales + popover "+ Filtro" + editor por chip + botón "Limpiar".\n\n**Campos soportados**\n- Built-in: Título, Descripción, Estado, Prioridad, Asignados, Etiquetas, Vencimiento, Creada.\n- Custom properties: text, number, select, multiselect, date, checkbox, url, email, person.\n\n**Operadores por tipo**\n- Texto: contiene, no contiene, es, no es, empieza/termina con, vacío/con valor.\n- Multi (status/priority/labels): es alguno de, no es ninguno de, vacío/con valor.\n- Asignados/person: + "soy yo".\n- Número: =, ≠, >, <, ≥, ≤, vacío/con valor.\n- Fecha: es / antes / después / en o antes / en o después / entre / vacío.\n- Checkbox: marcado / no marcado.\n\n**Plumbing**\n- `ProjectView`: reemplazado `search`+`assigneeFilter` por `taskFilters: TaskFilter[]`. `filtered` se calcula con `filterTasks(tasks, taskFilters, {project, currentUserId})` (client-side, sobre los datos ya cargados con lazy load).\n- `FiltersSheet` simplificado: mantiene kanban settings + saved filters; los controles search/assignee viejos eliminados (la barra los reemplaza).\n- Saved filters: al guardar uno nuevo se persiste `{filters: TaskFilter[]}`; al aplicar uno antiguo (con `search`/`assignee_filter`) se migra automáticamente con `fromLegacyConfig`.	2026-05-31 05:59:50.486321	2026-05-31 05:59:50.48635
\.


--
-- Data for Name: error_reports; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.error_reports (id, project_id, signature, app, environment, level, title, message, stack_trace, context, first_seen, last_seen, occurrences, status, linked_task_id, assignee_id, release, kind) FROM stdin;
\.


--
-- Data for Name: ingest_keys; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.ingest_keys (id, project_id, name, token_hash, created_at, last_used_at, created_by) FROM stdin;
\.


--
-- Data for Name: labels; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.labels (id, project_id, name, color) FROM stdin;
\.


--
-- Data for Name: mcp_tokens; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.mcp_tokens (id, user_id, name, token_hash, last_used_at, created_at, revoked_at) FROM stdin;
be5cc7ad-a109-4f65-a8be-1b669cfa8140	56f1614d-e66d-4d93-b090-33e03c34d084	tadiin	5cb6cb7b2fccf1463b600be09fb536b0edbd44994ab445e4db814a5ac01f1309	2026-05-29 03:55:22.869731	2026-05-22 14:51:49.011477	\N
11b3f9a8-058a-4eab-baf5-8b1a58ecc21b	56f1614d-e66d-4d93-b090-33e03c34d084	claude	55dd452ae501a97da1d513ef6b129f279ea56f8e49cab56366b148574a81874c	2026-05-31 05:46:36.399321	2026-05-22 14:08:01.084668	\N
68a5ba0d-42f4-4b18-843d-b1a470f5b72f	fc7a4bb9-6b76-4db2-9a18-0916159aa890	claude-cli-oI4rAZv6	6a7a3abb18829935b4f118f6647a247eb11dbc16fef24e012cd8f430bb4d65aa	2026-05-31 05:59:50.472599	2026-05-22 13:33:29.917734	\N
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.projects (id, name, description, color, owner_id, property_schema, created_at, kanban_settings, status_schema, feedback_enabled, icon) FROM stdin;
b962d64d-dd48-46cb-83bf-48d95e0689e7	EmptyTask		#6366f1	56f1614d-e66d-4d93-b090-33e03c34d084	[]	2026-05-22 04:24:51.027088	{"density": "normal", "group_by": "status", "visible_props": []}	[{"key": "todo", "color": "#94a3b8", "group": "todo", "label": "Por hacer"}, {"key": "doing", "color": "#3b82f6", "group": "doing", "label": "En curso"}, {"key": "done", "color": "#10b981", "group": "done", "label": "Hecho"}, {"key": "archived", "color": "#64748b", "group": "done", "label": "Archivado"}]	f	https://tasks.polymitia.tech/api/uploads/VDqymonfpUaH9mdLTOFQzQ.png
e44083dd-0913-4bb5-b107-afb978377446	Tadin	Proyecto Tadin	#6366f1	fc7a4bb9-6b76-4db2-9a18-0916159aa890	[{"key": "tadin_project", "name": "Tadin Proyect", "type": "multiselect", "options": ["Backend", "Frontend", "Documentacón", "Tools"]}, {"key": "tadin_id", "name": "Tadin ID", "type": "text", "options": []}]	2026-05-21 23:11:07.169123	{"density": "normal", "group_by": "status", "visible_props": ["tadin_project"]}	[{"key": "not_started", "color": "#9ca3af", "group": "todo", "label": "Not started"}, {"key": "backlog", "color": "#ec4899", "group": "todo", "label": "BackLog"}, {"key": "standby", "color": "#8b5cf6", "group": "todo", "label": "Standby"}, {"key": "in_progress", "color": "#3b82f6", "group": "doing", "label": "inProgress"}, {"key": "to_test", "color": "#a855f7", "group": "doing", "label": "toTest"}, {"key": "error", "color": "#ef4444", "group": "doing", "label": "error"}, {"key": "done", "color": "#10b981", "group": "done", "label": "Done"}]	f	https://tasks.polymitia.tech/api/uploads/PLk18fj69SBwVWKyXOpIJw.png
\.


--
-- Data for Name: saved_filters; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.saved_filters (id, project_id, user_id, name, config, created_at) FROM stdin;
\.


--
-- Data for Name: task_assignees; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.task_assignees (task_id, user_id) FROM stdin;
3b29ae36-c2d1-4c5a-a5ba-419a67bdb080	fc7a4bb9-6b76-4db2-9a18-0916159aa890
7234bb95-02ed-4933-8446-0cf87071d4fa	fc7a4bb9-6b76-4db2-9a18-0916159aa890
7234bb95-02ed-4933-8446-0cf87071d4fa	85640f10-ec4c-4088-b6ff-41cb2031aae8
f0b4ca8b-c85e-4576-ae8c-00a76eea6289	a9a0509e-c92a-4242-802b-f5136b06a5df
5c2f07d1-2b71-4585-9f53-b798c31ed4a8	fc7a4bb9-6b76-4db2-9a18-0916159aa890
10d138c7-9526-40f9-997c-bb0c69b4b346	fc7a4bb9-6b76-4db2-9a18-0916159aa890
5f78cc16-c2c3-45fe-a7fe-98e834805e5d	fc7a4bb9-6b76-4db2-9a18-0916159aa890
5f78cc16-c2c3-45fe-a7fe-98e834805e5d	56f1614d-e66d-4d93-b090-33e03c34d084
5f78cc16-c2c3-45fe-a7fe-98e834805e5d	a9a0509e-c92a-4242-802b-f5136b06a5df
5f78cc16-c2c3-45fe-a7fe-98e834805e5d	85640f10-ec4c-4088-b6ff-41cb2031aae8
810fc5f4-dcc1-45e1-b566-4aeacc8a75c3	85640f10-ec4c-4088-b6ff-41cb2031aae8
7c91ad58-443d-4931-bbf2-a6581a299092	fc7a4bb9-6b76-4db2-9a18-0916159aa890
059cbad3-21fc-49a0-a217-33f4d3b0a250	85640f10-ec4c-4088-b6ff-41cb2031aae8
2a3ba5be-b906-42aa-bc39-0c45217fa3af	fc7a4bb9-6b76-4db2-9a18-0916159aa890
2a3ba5be-b906-42aa-bc39-0c45217fa3af	85640f10-ec4c-4088-b6ff-41cb2031aae8
d2161c26-0729-437a-b321-75117b16514b	fc7a4bb9-6b76-4db2-9a18-0916159aa890
6a42843a-2ade-420c-aa95-bde9cf834aad	fc7a4bb9-6b76-4db2-9a18-0916159aa890
9fcdb127-10d5-498f-836d-6eb77ff6b109	56f1614d-e66d-4d93-b090-33e03c34d084
94b7fafa-1808-4394-a5f1-71480b827071	fc7a4bb9-6b76-4db2-9a18-0916159aa890
c9167178-1aac-4b79-8095-b9599fe9a793	56f1614d-e66d-4d93-b090-33e03c34d084
6a0c5d2b-d158-4647-bd18-0b607d214564	a9a0509e-c92a-4242-802b-f5136b06a5df
dd4efb77-96e3-4c92-a25d-f07063840cf4	85640f10-ec4c-4088-b6ff-41cb2031aae8
1299f8cd-8569-4293-ba1e-dd55990b65e4	85640f10-ec4c-4088-b6ff-41cb2031aae8
3c757953-612e-4cde-a385-670c0da10e97	a9a0509e-c92a-4242-802b-f5136b06a5df
1c98ac95-5737-4f1a-8f59-55b13f974224	fc7a4bb9-6b76-4db2-9a18-0916159aa890
6361eefe-7be4-42a8-8ee4-c9a6d690c034	85640f10-ec4c-4088-b6ff-41cb2031aae8
fd4519d5-f261-4a29-a262-cab6682fb9a2	fc7a4bb9-6b76-4db2-9a18-0916159aa890
fd4519d5-f261-4a29-a262-cab6682fb9a2	85640f10-ec4c-4088-b6ff-41cb2031aae8
42cb8560-2f39-4336-8c11-31306a1a1038	85640f10-ec4c-4088-b6ff-41cb2031aae8
76213fa5-65bd-4d01-af55-8939ad83a4d5	fc7a4bb9-6b76-4db2-9a18-0916159aa890
6363e67d-12e2-4749-a2b1-20ac454f6812	85640f10-ec4c-4088-b6ff-41cb2031aae8
f65cd435-eea0-4854-9ef9-b1c27ec896ba	fc7a4bb9-6b76-4db2-9a18-0916159aa890
aafbdd9e-4957-42bc-aa95-f4e80e8494a5	fc7a4bb9-6b76-4db2-9a18-0916159aa890
aafbdd9e-4957-42bc-aa95-f4e80e8494a5	85640f10-ec4c-4088-b6ff-41cb2031aae8
45637336-9b66-473d-9d81-37afe371a880	a9a0509e-c92a-4242-802b-f5136b06a5df
76b895bf-14ed-48a9-b4f9-afb5de5be5fb	85640f10-ec4c-4088-b6ff-41cb2031aae8
d2dbb8f0-bff0-48b2-94b2-e25c3e0a2155	85640f10-ec4c-4088-b6ff-41cb2031aae8
adafe8d4-99d5-49ca-824d-e237071b9c57	85640f10-ec4c-4088-b6ff-41cb2031aae8
11e32319-774e-4b97-9aef-cec2cafd3920	85640f10-ec4c-4088-b6ff-41cb2031aae8
9a263964-0b5f-46ca-9098-585809bd7818	56f1614d-e66d-4d93-b090-33e03c34d084
d44f86de-47fa-4b72-8ea1-adfbeb0025e9	fc7a4bb9-6b76-4db2-9a18-0916159aa890
d44f86de-47fa-4b72-8ea1-adfbeb0025e9	85640f10-ec4c-4088-b6ff-41cb2031aae8
9d878b91-7650-4964-a565-4bd9d2999442	85640f10-ec4c-4088-b6ff-41cb2031aae8
408760a1-b486-4ed4-902c-3526233e9781	85640f10-ec4c-4088-b6ff-41cb2031aae8
11771a27-830f-474e-85d2-8bdf0caabfdc	fc7a4bb9-6b76-4db2-9a18-0916159aa890
16cec1ae-42f9-4391-ab8e-93810a0bb976	85640f10-ec4c-4088-b6ff-41cb2031aae8
1c51a682-8978-41c8-9ab3-dbf6e5060131	fc7a4bb9-6b76-4db2-9a18-0916159aa890
1c51a682-8978-41c8-9ab3-dbf6e5060131	56f1614d-e66d-4d93-b090-33e03c34d084
1c51a682-8978-41c8-9ab3-dbf6e5060131	a9a0509e-c92a-4242-802b-f5136b06a5df
1c51a682-8978-41c8-9ab3-dbf6e5060131	85640f10-ec4c-4088-b6ff-41cb2031aae8
97514ebe-ee51-46f1-b655-d08a38232eff	a9a0509e-c92a-4242-802b-f5136b06a5df
99d9624b-b040-41c2-9cb9-f86db2f206f2	85640f10-ec4c-4088-b6ff-41cb2031aae8
a8631421-09bb-4906-8775-b6ded5daa3a0	fc7a4bb9-6b76-4db2-9a18-0916159aa890
a8631421-09bb-4906-8775-b6ded5daa3a0	56f1614d-e66d-4d93-b090-33e03c34d084
a8631421-09bb-4906-8775-b6ded5daa3a0	a9a0509e-c92a-4242-802b-f5136b06a5df
a8631421-09bb-4906-8775-b6ded5daa3a0	85640f10-ec4c-4088-b6ff-41cb2031aae8
448f036a-bdb8-46c3-8e6c-ea35d85ebb53	85640f10-ec4c-4088-b6ff-41cb2031aae8
822a4964-6538-4e1b-8a3e-88d618ed04ff	fc7a4bb9-6b76-4db2-9a18-0916159aa890
8a9c77cc-e343-4e74-857a-557fb150cc9f	fc7a4bb9-6b76-4db2-9a18-0916159aa890
727b4cc2-2b30-4a15-9c59-43453712727c	a9a0509e-c92a-4242-802b-f5136b06a5df
41a90fb7-18ae-4a98-9749-f93b033e1fb9	fc7a4bb9-6b76-4db2-9a18-0916159aa890
4b639a7f-9d12-418b-b065-6467dde547e7	fc7a4bb9-6b76-4db2-9a18-0916159aa890
f719efdd-9051-47de-aba3-56b0c0b4605a	fc7a4bb9-6b76-4db2-9a18-0916159aa890
f2b7194c-b3a6-4190-80a7-08664ec51d48	fc7a4bb9-6b76-4db2-9a18-0916159aa890
050db125-a8dd-45e4-b5a3-742bb013e386	a9a0509e-c92a-4242-802b-f5136b06a5df
050db125-a8dd-45e4-b5a3-742bb013e386	85640f10-ec4c-4088-b6ff-41cb2031aae8
3e5c3389-50c7-4495-9cfc-a2f9275bea33	85640f10-ec4c-4088-b6ff-41cb2031aae8
b2c6e14c-18c3-4650-a513-e697f7abcd8c	85640f10-ec4c-4088-b6ff-41cb2031aae8
52929b0b-aeb1-4699-ab7b-fa9b7991d811	85640f10-ec4c-4088-b6ff-41cb2031aae8
d1e3fffb-69b4-424e-bbce-c42fa75ff5d4	fc7a4bb9-6b76-4db2-9a18-0916159aa890
7fee32db-394a-41c8-9c99-4b688523db70	85640f10-ec4c-4088-b6ff-41cb2031aae8
7fee32db-394a-41c8-9c99-4b688523db70	a9a0509e-c92a-4242-802b-f5136b06a5df
2458e663-fd49-4d53-8506-75291fa69fa9	85640f10-ec4c-4088-b6ff-41cb2031aae8
5bd159e4-746c-4f1b-bce7-d91c7ddae768	56f1614d-e66d-4d93-b090-33e03c34d084
0f02c8ce-fa8f-490d-98ed-c1f02a6c361e	56f1614d-e66d-4d93-b090-33e03c34d084
cd4a7ef9-4951-4c9d-90fa-7cc702c2c7d6	56f1614d-e66d-4d93-b090-33e03c34d084
1a95f8a3-fea9-405f-9fb8-a3a10a8d369e	56f1614d-e66d-4d93-b090-33e03c34d084
cf087882-5016-4a89-a610-a98a72a79417	85640f10-ec4c-4088-b6ff-41cb2031aae8
8ab0d158-7244-4235-91ca-15a8e3415385	fc7a4bb9-6b76-4db2-9a18-0916159aa890
a27e1060-3c97-43eb-92ff-73e8c6177615	fc7a4bb9-6b76-4db2-9a18-0916159aa890
4f1c028a-bea9-41d7-a430-eb71c278b3b3	85640f10-ec4c-4088-b6ff-41cb2031aae8
838e44ff-94d9-402a-a241-cee6ba782d76	56f1614d-e66d-4d93-b090-33e03c34d084
838e44ff-94d9-402a-a241-cee6ba782d76	85640f10-ec4c-4088-b6ff-41cb2031aae8
65376f1e-1ea4-45fd-a2cb-9ae380ddcf89	85640f10-ec4c-4088-b6ff-41cb2031aae8
6b0bc0a8-50bc-4842-86ec-c339a33ce819	fc7a4bb9-6b76-4db2-9a18-0916159aa890
62f8d489-4072-4fba-9360-d6eafa8973ff	56f1614d-e66d-4d93-b090-33e03c34d084
62f8d489-4072-4fba-9360-d6eafa8973ff	85640f10-ec4c-4088-b6ff-41cb2031aae8
af76edaf-c9bc-46a0-a2fa-8bb379d1effb	56f1614d-e66d-4d93-b090-33e03c34d084
f9868316-f2d4-43da-a5ff-9a8546e302af	56f1614d-e66d-4d93-b090-33e03c34d084
84849db3-2f4d-4d3e-bcdc-486d66acc432	56f1614d-e66d-4d93-b090-33e03c34d084
07db5a37-f0df-42bd-a545-01ed8524fe71	56f1614d-e66d-4d93-b090-33e03c34d084
1b34b0f0-112e-4e7c-8b5c-b4e60e6dc87c	56f1614d-e66d-4d93-b090-33e03c34d084
ae2aecca-ae03-4fc5-a69c-3529e617e316	a9a0509e-c92a-4242-802b-f5136b06a5df
f98ddb21-94ad-4193-9d85-a6f783a36089	fc7a4bb9-6b76-4db2-9a18-0916159aa890
5f139966-ee4c-4ca3-a4e5-7a09a38ae353	a9a0509e-c92a-4242-802b-f5136b06a5df
05462b10-4ecc-409a-8533-52b296ae232e	85640f10-ec4c-4088-b6ff-41cb2031aae8
ac1317d8-db93-4152-b4bd-f2d3e158650d	85640f10-ec4c-4088-b6ff-41cb2031aae8
4bb488ba-ffe8-41de-a475-3cc6a4278e52	fc7a4bb9-6b76-4db2-9a18-0916159aa890
723801a1-eec5-4c16-9c05-b80d1b566895	fc7a4bb9-6b76-4db2-9a18-0916159aa890
b26688e7-6c10-461d-b16a-99714f32f028	fc7a4bb9-6b76-4db2-9a18-0916159aa890
803def6e-79f2-4ff1-96c8-0fa32d1fe22d	fc7a4bb9-6b76-4db2-9a18-0916159aa890
785402d5-698e-4029-9124-b208a70b5c69	85640f10-ec4c-4088-b6ff-41cb2031aae8
5e7b9edd-8b2f-4b0f-b1a3-734b299bf828	85640f10-ec4c-4088-b6ff-41cb2031aae8
bea1841e-04c5-4646-a48b-8087526ba5c0	56f1614d-e66d-4d93-b090-33e03c34d084
def4d096-d323-4617-875c-de8ed0e607e7	fc7a4bb9-6b76-4db2-9a18-0916159aa890
4ae085c4-80df-4f40-82f3-e16a3cbf6bf1	85640f10-ec4c-4088-b6ff-41cb2031aae8
e10b044b-7530-481f-84e0-e5c321fb0648	fc7a4bb9-6b76-4db2-9a18-0916159aa890
fa1f7a4b-722b-4114-863e-8be04c3202f6	56f1614d-e66d-4d93-b090-33e03c34d084
f8c08c90-e266-4bf6-bc5b-0117db1609c7	56f1614d-e66d-4d93-b090-33e03c34d084
ec4ea125-0cda-4139-81a5-a591178d9e81	85640f10-ec4c-4088-b6ff-41cb2031aae8
f367d804-e223-468f-86e9-788fc80da059	56f1614d-e66d-4d93-b090-33e03c34d084
a71eb9cc-e09f-42a5-a057-8ae9cc0bcac7	85640f10-ec4c-4088-b6ff-41cb2031aae8
ef1d7a95-16ed-4b11-afb7-24104d9360a6	56f1614d-e66d-4d93-b090-33e03c34d084
ebfab4f7-bef2-406d-9758-af9dd0404168	56f1614d-e66d-4d93-b090-33e03c34d084
605224d9-6d10-4982-a459-f87cf68fa1c7	85640f10-ec4c-4088-b6ff-41cb2031aae8
308ca1aa-0101-4c9d-a6f9-3861eb468848	56f1614d-e66d-4d93-b090-33e03c34d084
098d5599-9d51-4f3a-a44c-eee98cf3b3a2	85640f10-ec4c-4088-b6ff-41cb2031aae8
f5923117-6d4b-40d7-85bf-b6bc6f6f2af2	56f1614d-e66d-4d93-b090-33e03c34d084
f5923117-6d4b-40d7-85bf-b6bc6f6f2af2	85640f10-ec4c-4088-b6ff-41cb2031aae8
f5923117-6d4b-40d7-85bf-b6bc6f6f2af2	a9a0509e-c92a-4242-802b-f5136b06a5df
f5923117-6d4b-40d7-85bf-b6bc6f6f2af2	fc7a4bb9-6b76-4db2-9a18-0916159aa890
0bd14e57-12f6-4f4a-8c49-6d4591b2c20e	fc7a4bb9-6b76-4db2-9a18-0916159aa890
6cbe5e8b-00a3-4fc0-8a00-7d9408280643	56f1614d-e66d-4d93-b090-33e03c34d084
e6e639c5-0ff5-42f7-aaaf-bbb0e93cf63e	a9a0509e-c92a-4242-802b-f5136b06a5df
48b4fd9b-71e7-4717-902b-e03a77f10889	a9a0509e-c92a-4242-802b-f5136b06a5df
9f5c8c81-e304-4874-986c-190a6aabc122	fc7a4bb9-6b76-4db2-9a18-0916159aa890
4d381c23-8cb6-450e-a53b-9ea0b7ee1e4e	fc7a4bb9-6b76-4db2-9a18-0916159aa890
869780b2-daaa-4725-a93c-17a68a804827	fc7a4bb9-6b76-4db2-9a18-0916159aa890
46205602-5317-4bd4-8f0b-2ccc9b7286b7	fc7a4bb9-6b76-4db2-9a18-0916159aa890
9a81bde6-6e87-41b1-86ed-d111ccfb4e18	56f1614d-e66d-4d93-b090-33e03c34d084
b8b17bfa-18e2-4607-9b98-fe44ea8ac118	56f1614d-e66d-4d93-b090-33e03c34d084
9bcb6921-1825-438e-8384-4d313738f48c	fc7a4bb9-6b76-4db2-9a18-0916159aa890
3468f343-484e-46da-b73c-3a369a75349c	fc7a4bb9-6b76-4db2-9a18-0916159aa890
6b9d3b05-11d8-4e21-8ff7-04c3f015140c	fc7a4bb9-6b76-4db2-9a18-0916159aa890
6b9d3b05-11d8-4e21-8ff7-04c3f015140c	56f1614d-e66d-4d93-b090-33e03c34d084
6edd2329-5f48-4c33-b920-47707d528f72	56f1614d-e66d-4d93-b090-33e03c34d084
f0dbb3e1-f966-44bc-a31d-8bbaa3a4c66d	56f1614d-e66d-4d93-b090-33e03c34d084
8b74cc5e-1710-4d34-a6c4-13b56fcf7b51	56f1614d-e66d-4d93-b090-33e03c34d084
fcddd162-7eb6-46e0-be62-3ca4d2c1d15c	56f1614d-e66d-4d93-b090-33e03c34d084
c7344611-467a-461c-ab4f-65d0fec690ad	fc7a4bb9-6b76-4db2-9a18-0916159aa890
ad5ca941-76c5-4c73-9004-473b9eb0c2c9	fc7a4bb9-6b76-4db2-9a18-0916159aa890
1699e40d-763d-46ce-a0b8-7c8bcfa46b75	fc7a4bb9-6b76-4db2-9a18-0916159aa890
05fd5ea9-a126-4385-b25c-8f13d489a387	56f1614d-e66d-4d93-b090-33e03c34d084
0e384b18-27fa-4d4c-bcd4-212cb334f5e9	fc7a4bb9-6b76-4db2-9a18-0916159aa890
\.


--
-- Data for Name: task_labels; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.task_labels (task_id, label_id) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.tasks (id, project_id, parent_task_id, title, description, status, priority, due_date, "position", created_by, properties, created_at, updated_at, due_date_end, icon, cover_url) FROM stdin;
9f5c8c81-e304-4874-986c-190a6aabc122	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar Feedback de errores		not_started	normal	\N	12	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{}	2026-05-22 15:03:08.548467	2026-05-22 15:03:08.548497	\N	\N	\N
ad5ca941-76c5-4c73-9004-473b9eb0c2c9	e44083dd-0913-4bb5-b107-afb978377446	\N	🎃🎄 Chiste malo del día (para Hal/Halexy)	Fer te manda este chiste malo por WhatsApp pero el canal no está conectado, así que te llega por Tareapp:\n\n---\n\n— Hal, ¿por qué los programadores confunden Halloween con Navidad?\n\n— Porque **Oct 31 = Dec 25**\n\n(Octal 31 = Decimal 25 🎃🎄)\n\n---\n\n*Enviado por AgenteParaPruebas luego de 223 intentos fallidos por WhatsApp.*	backlog	low	\N	8	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-25 11:21:55.958368	2026-05-25 11:21:55.958388	\N	\N	\N
0e384b18-27fa-4d4c-bcd4-212cb334f5e9	b962d64d-dd48-46cb-83bf-48d95e0689e7	\N	Copia los filtros de notion y que se pueda limpiar los filtros con un boton 		done	normal	\N	7	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-30 05:30:02.0101	2026-05-31 05:59:40.493319	\N	\N	\N
0bf4fe43-2a5c-4fa7-8d1f-c3f53e989c25	b962d64d-dd48-46cb-83bf-48d95e0689e7	\N	Tap en notificación FCM no abría la APK	El payload de FCM incluía `click_action: FCM_PLUGIN_ACTIVITY` (intent legacy de Cordova). Capacitor no registra ese intent-filter, por lo que tocar la notificación no encontraba Activity y no abría la app.	done	high	\N	6	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{}	2026-05-25 14:18:04.572306	2026-05-25 14:18:04.572347	\N	\N	\N
4d381c23-8cb6-450e-a53b-9ea0b7ee1e4e	b962d64d-dd48-46cb-83bf-48d95e0689e7	\N	Skeleton load para todo		done	normal	\N	3	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{}	2026-05-22 16:29:44.958499	2026-05-23 23:51:53.533623	\N	\N	\N
1699e40d-763d-46ce-a0b8-7c8bcfa46b75	e44083dd-0913-4bb5-b107-afb978377446	\N	Hacer q el helper tenga conocimiento de q existen bases de conocimiento y q el builder pueda crearlas y subir las bases		not_started	urgent	\N	14	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{}	2026-05-25 14:40:44.38072	2026-05-25 14:40:53.636403	\N	\N	\N
869780b2-daaa-4725-a93c-17a68a804827	b962d64d-dd48-46cb-83bf-48d95e0689e7	\N	Lazy load de tareas		done	normal	\N	4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{}	2026-05-22 16:29:58.307647	2026-05-23 23:51:53.961586	\N	\N	\N
9a81bde6-6e87-41b1-86ed-d111ccfb4e18	e44083dd-0913-4bb5-b107-afb978377446	\N	No se estan subiendo los documentos en el chat 		done	normal	\N	2	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-22 04:55:47.519837	2026-05-24 03:37:11.147978	\N	\N	\N
95a74ca6-1121-4053-a4f9-40c130a0e498	e44083dd-0913-4bb5-b107-afb978377446	\N	El canal de wsapp se cae tras el el agente enviar un mensaje directo a un usuario	Cuando se le solicita a un agente conectado al canal d wsapp que envíe un mensaje a un número en especifico despues de enviar el mensaje se desconecta el canal 	done	normal	\N	19	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-27 03:03:22.068487	2026-05-27 17:59:11.831833	\N	\N	\N
f2b7194c-b3a6-4190-80a7-08664ec51d48	b962d64d-dd48-46cb-83bf-48d95e0689e7	\N	Agregar un color distinto a la targeta para cada estado 		done	low	\N	0	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-22 14:03:05.96712	2026-05-22 14:04:12.847386	\N	\N	\N
4b639a7f-9d12-418b-b065-6467dde547e7	b962d64d-dd48-46cb-83bf-48d95e0689e7	\N	Los comentarios deben poder editarse 	a	done	normal	\N	0	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-22 04:25:30.669066	2026-05-22 13:42:41.560581	\N	\N	\N
41a90fb7-18ae-4a98-9749-f93b033e1fb9	b962d64d-dd48-46cb-83bf-48d95e0689e7	\N	Cuando le pase el maus por encima a una tarea de ser posible que se vean los comentarios 		done	normal	\N	1	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-22 04:26:02.304126	2026-05-22 13:42:42.105857	\N	\N	\N
f719efdd-9051-47de-aba3-56b0c0b4605a	b962d64d-dd48-46cb-83bf-48d95e0689e7	\N	Eliminar tokens MCP revocados		done	normal	\N	2	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{}	2026-05-22 13:57:10.952221	2026-05-22 14:00:40.250986	\N	\N	\N
a06d86c0-8b36-4a64-be44-0afe77da49f6	e44083dd-0913-4bb5-b107-afb978377446	\N	Soporte para tools con ollama cloud	Los modelos de ollama cloud que tienen soporte para tools igual no funcionan con tools.	done	normal	\N	5	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3556d245-8bcb-8079-ad64-ea1c4a201c95", "tadin_project": []}	2026-05-21 23:11:23.124915	2026-05-22 19:45:50.038692	\N	\N	\N
05fd5ea9-a126-4385-b25c-8f13d489a387	e44083dd-0913-4bb5-b107-afb978377446	\N	Lograr que los tres lugares desde los que se puede asignar bases de conocimiento a los agentes sen un solo systema	Al asignar una base de conocimiento a un agente durante la creación  y  desde la interfaz simple de las bases de conocimiento todo funciona bien , el problema viene dado cuando se asigna o quita una base de conocimiento a un agente desde la interfaz avanzada . Se quita de la interfaz simple de la base de conocimiento pero no del formulario de edición del agente (Y aunque la tenga asignada desde el formulario el agente no puede consultar realmente la base de conocimiento ) . Esto nos lleva a la conclución de que enrealidad hay 2 sistemas separados para asignar una base de conocimiento a un agente (Desde el formulario de creación y edición del agente y desde las interfaces de creación y gstión de las bases de conocimiento )\n 	to_test	normal	\N	20	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-27 03:37:51.910085	2026-05-27 18:32:12.664933	\N	\N	\N
ff5949f5-9a58-41d9-a7d8-dfec2e0be590	e44083dd-0913-4bb5-b107-afb978377446	\N	Los agentes conectados a wsapp no son capaces de mandar imágenes	Si le pido a un agente desde wsapp que me mande una foto dice que no puede. Si le pido a un agente desde tadin que envie una imagen por wsapp me pide el numero de telefono.	done	urgent	\N	48	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "35d6d245-8bcb-806a-8b49-ca2e1327002f", "tadin_project": []}	2026-05-21 23:11:31.922882	2026-05-23 05:10:32.240579	\N	\N	\N
b4f552a5-67e0-4b24-98c6-89ae7250d3eb	e44083dd-0913-4bb5-b107-afb978377446	\N	Reconectar canal de WhatsApp - "Not connected" tras 93 intentos	El canal de WhatsApp está completamente caído. Se intentó desde el agente AgenteParaPruebas en 93 ocasiones distintas, tanto `whatsapp_enviar_mensaje` como `whatsapp_get_contacts`, y siempre devuelve error de conexión ("Not connected").\n\n**Impacto:** No se pueden enviar mensajes ni buscar contactos por WhatsApp.\n\n**Acción necesaria:** Revisar y reconectar el canal de WhatsApp en el servidor/infraestructura.\n\n**Tarea creada automáticamente por AgenteParaPruebas** el 2026-05-25.	done	urgent	\N	18	56f1614d-e66d-4d93-b090-33e03c34d084	{"tadin_project": ["Backend", "Tools"]}	2026-05-25 06:23:39.392921	2026-05-27 17:59:03.093311	\N	\N	\N
9bcb6921-1825-438e-8384-4d313738f48c	e44083dd-0913-4bb5-b107-afb978377446	\N	Agentes conectados a wsapp solicitan el numero de telefono para enviar un mensaje 	El canal de wsapp es una herramienta especial que se le asign a los agentes para comunicarse por wsapp , estos agentes que estan conectados a wsapp tienen una  herramienta independiente para mandar imagenes . Lo que se busca es que el comportamiento del envio de imagenes por wsapp sea el mismo que el de envio de documentos y que el agente no solicite el numero de telefono del usuario para poder enviar la imagen  .	done	normal	\N	0	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-23 05:20:31.458114	2026-05-27 03:00:47.288098	\N	\N	\N
10f95d2d-8750-42ac-a745-0a1e323bfa1d	e44083dd-0913-4bb5-b107-afb978377446	\N	Mensajes en el chat se desorganizan al salir y volver a entrar al chat de la oficina 	Ademas muestra mensajes de llamadas a base de conocimientos < esto ocurre en la oficina de Auditorias de España que es una oficina bastante cargada de agentes y bases de conocimiento 	error	normal	\N	18	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-29 03:49:49.510687	2026-05-29 03:49:49.510717	\N	\N	\N
3468f343-484e-46da-b73c-3a369a75349c	b962d64d-dd48-46cb-83bf-48d95e0689e7	\N	Que se pueda compactar y descompletar cada sesión en la vista de lista 	En la vista de lista las tareas están separadas por estados , agregar la funcionalidad de que se puedan compactar cada list de las diferentes secciones de estado 	done	normal	\N	5	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-24 00:57:43.941533	2026-05-25 14:13:56.174628	\N	\N	\N
9cf5e4c7-ad23-405d-b75b-263dcab86263	e44083dd-0913-4bb5-b107-afb978377446	\N	Bitacora	Ya todo lo que tiene que ver con la Bitacora fue removido , todo queda en el chat global como debio ser desde un inicio 	done	normal	\N	15	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-29 03:50:39.637023	2026-05-30 05:10:34.328149	\N	\N	\N
8b74cc5e-1710-4d34-a6c4-13b56fcf7b51	e44083dd-0913-4bb5-b107-afb978377446	\N	Boton de agentes en base de conocimiento no funciona 	Si creo un agente y desde la creacion le asigno una base de concimiento, el boton agentes q puede acceder a la base de conocimientos en la lista de base de conocimientos en una oficina no quita al agente de la base de conocimiento	done	normal	\N	13	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{}	2026-05-24 01:17:48.820469	2026-05-27 03:24:09.775835	\N	\N	\N
61bc33ec-a755-46a5-832b-0e69fa7e88b8	e44083dd-0913-4bb5-b107-afb978377446	\N	EL helper no edita bien los agentes 	Cuando tenemos una oficina creada con agentes y estos agentes no tenen credencial asignada y le pedimos al helper que les asigne una credencial , visualmente el agente tiene la credencial correcta asignada pero en el chat da error  de credencial .![](https://tasks.polymitia.tech/api/uploads/xfLXjebYJvS1FdzlHipGZg.png)\n	error	normal	\N	19	56f1614d-e66d-4d93-b090-33e03c34d084	{"tadin_project": ["Frontend", "Backend"]}	2026-05-29 15:18:58.879186	2026-05-30 05:08:11.327529	\N	\N	\N
727b4cc2-2b30-4a15-9c59-43453712727c	e44083dd-0913-4bb5-b107-afb978377446	\N	Bug Premium de Carlitos	Si das tab 7 tadbs en el chat global se rompe la UI o Si tocas el icono equipo, lo cierras or la x y tocas tab ocurre	to_test	low	\N	10	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Frontend", "Backend"]}	2026-05-22 04:37:16.090496	2026-05-30 05:09:05.128846	\N	\N	\N
6363e67d-12e2-4749-a2b1-20ac454f6812	e44083dd-0913-4bb5-b107-afb978377446	\N	Ajustar respuestas de agentes para considerar mejor el contexto	Mejorar la coherencia y relevancia de las respuestas de los agentes considerando mejor el contexto histórico.	to_test	urgent	\N	3	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "32d6d245-8bcb-8185-8359-eef9437e04c0", "tadin_project": ["Documentacón"]}	2026-05-21 23:11:43.088908	2026-05-24 03:38:01.176051	\N	\N	\N
fcddd162-7eb6-46e0-be62-3ca4d2c1d15c	e44083dd-0913-4bb5-b107-afb978377446	\N	Editar agente falla al deseleccionar una base de conocimiento		done	normal	\N	14	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{}	2026-05-24 01:18:21.693776	2026-05-27 03:31:09.526475	\N	\N	\N
3b29ae36-c2d1-4c5a-a5ba-419a67bdb080	e44083dd-0913-4bb5-b107-afb978377446	\N	Tasks Con triggers	Hacer q las tasks puedan ejecutarse periodicamente con un trigger.\n\nLos agentes al finalizar cada tarea hara un resumen de pasos q utilizo para completar la tarea, asi en futuras iteraciones fallaria menos y/o ahorraria tokens	standby	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3576d245-8bcb-8005-abb1-ef3c1bb4b634", "tadin_project": []}	2026-05-21 23:11:07.959336	2026-05-27 04:53:02.633695	\N	\N	\N
eafd0a2b-9538-46d8-94c1-05dd188a6435	e44083dd-0913-4bb5-b107-afb978377446	\N	Mejorar estrategia de procesamiento de excels		not_started	high	\N	1	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3656d245-8bcb-80f7-822a-ded3172b8350", "tadin_project": []}	2026-05-21 23:11:09.443658	2026-05-21 23:11:09.443687	\N	\N	\N
9d1e3f1a-f3af-437d-bc9e-5e562b1a9dae	e44083dd-0913-4bb5-b107-afb978377446	\N	Ajustar las skills		backlog	low	\N	2	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-8083-9400-d0b086a4e930", "tadin_project": []}	2026-05-21 23:11:28.877746	2026-05-21 23:11:28.87777	\N	\N	\N
7234bb95-02ed-4933-8446-0cf87071d4fa	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglos al sistema de tareas	Tuve que pedirle al agente que creara las tareas directamente\n\nOsea ya se lo pedi antes pero como empieza a responder el agente al que le delega la tarea entonces no termina creando las tareas para el siguiente agente\n\nAdemas despues de que creó las tareas me sale esto 0/0 tareas y no me responden mas los agentes en esa seción de chat	in_progress	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3476d245-8bcb-80c5-95b0-e9b3e592dbd3", "tadin_project": []}	2026-05-21 23:11:08.693045	2026-05-21 23:11:08.693069	\N	\N	\N
f0b4ca8b-c85e-4576-ae8c-00a76eea6289	e44083dd-0913-4bb5-b107-afb978377446	\N	Revisar todas las funcionalidades del helper y el builder dejar comentarios en esta tarea con los problemas que se encuentren	1. Listar todas las herramientas del helper\n2. Listar todos los skills que tiene el helper\n3. Probar uno a uno todas las tools (deja un comentario con cada problema encontrado)	in_progress	urgent	\N	1	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3516d245-8bcb-806f-9aeb-f3d0c96903d9", "tadin_project": []}	2026-05-21 23:11:10.109363	2026-05-21 23:11:10.109381	\N	\N	\N
5c2f07d1-2b71-4585-9f53-b798c31ed4a8	e44083dd-0913-4bb5-b107-afb978377446	\N	Chat de oficina con cambio de agente	El chat de oficina tendra la opcion de que todos los agente escuchen (por defecto desactivado). El manager invocara al mejor agente para una tarea simple q el usuario pida y se cambiara a un 'modo de chat directo' con ese agente hasta q se detecte un fin de conversacion o cambio de contexto.	not_started	normal	\N	3	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3586d245-8bcb-803c-9621-de2e9b748200", "tadin_project": []}	2026-05-21 23:11:11.441312	2026-05-21 23:11:11.441346	\N	\N	\N
10d138c7-9526-40f9-997c-bb0c69b4b346	e44083dd-0913-4bb5-b107-afb978377446	\N	Mejoras progresivas en los agentes	Los agentes se deben mejorar con feedback del propio usuario desde el chat global	not_started	normal	\N	4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3576d245-8bcb-80c8-8635-f3c9bdf56e3a", "tadin_project": []}	2026-05-21 23:11:12.069217	2026-05-21 23:11:12.069243	\N	\N	\N
5f78cc16-c2c3-45fe-a7fe-98e834805e5d	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar credenciales de herramientas a las oficinas importadas	Cuando se importa una oficina esta biene sin credenciales, hay que encontrar la forma en que sea comodo para el usuario agregar credenciales a las herramientas.	in_progress	normal	\N	2	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3556d245-8bcb-8023-92b0-c0db2a9fefcf", "tadin_project": []}	2026-05-21 23:11:12.651098	2026-05-21 23:11:12.65116	\N	\N	\N
810fc5f4-dcc1-45e1-b566-4aeacc8a75c3	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar Plan del Helper	En el chat con el helper si le das a haceptar plan sales del chat a hacer cualquier cosa y vuelves a entrar hay que volver a darle haceptar al plan.	done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-80a8-9b2f-fb3907adf800", "tadin_project": []}	2026-05-21 23:11:13.430569	2026-05-21 23:11:13.430596	\N	\N	\N
48b7cd07-2a59-4dcf-b759-59e0b92ce8fe	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar Configuración de canales con el helper	A la hora de configurar un canal desde el helper no se recupera el formulario original, se crea uno que solo admite texto.	done	normal	\N	1	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-807c-96aa-f4890da2363e", "tadin_project": []}	2026-05-21 23:11:14.182068	2026-05-21 23:11:14.182085	\N	\N	\N
2a3ba5be-b906-42aa-bc39-0c45217fa3af	e44083dd-0913-4bb5-b107-afb978377446	\N	Providers remotes	Errores en gemini/anthropic/openai cuando falta API key.	done	urgent	\N	7	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3166d245-8bcb-8054-818a-e6d94f9c6827", "tadin_project": ["Backend"]}	2026-05-21 23:11:17.576022	2026-05-22 08:14:58.719037	\N	\N	\N
312bd9ce-f26c-4706-af20-057e2261b5de	e44083dd-0913-4bb5-b107-afb978377446	\N	Cuando se crea una oficina con el helper no se esta configurando el manager	si lo configura lo que le pone la api key que le sale del huevo	done	normal	\N	8	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3506d245-8bcb-80f4-b174-d6cae3605b62", "tadin_project": []}	2026-05-21 23:11:18.330235	2026-05-22 08:14:58.725897	\N	\N	\N
d2161c26-0729-437a-b321-75117b16514b	e44083dd-0913-4bb5-b107-afb978377446	\N	Bug ollama provider local	los errores: No module named 'langchain_ollama'	done	high	2026-02-28	9	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-808d-9078-e320342861ef", "tadin_project": []}	2026-05-21 23:11:19.122571	2026-05-22 08:14:58.732493	\N	\N	\N
6a42843a-2ade-420c-aa95-bde9cf834aad	e44083dd-0913-4bb5-b107-afb978377446	\N	Error remote providers	Error: list indices must be integers or slices, not str. Esto pasa cuando seleccionas un provider remoto con una key	done	high	2026-02-28	10	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-808c-b538-ebe150a0180a", "tadin_project": []}	2026-05-21 23:11:19.835665	2026-05-22 08:14:58.740153	\N	\N	\N
9fcdb127-10d5-498f-836d-6eb77ff6b109	e44083dd-0913-4bb5-b107-afb978377446	\N	Las herramientas con autenticacion deben pder tener mas de una credencial y asignar las credenciales a los agentes	Problemas con credenciales OAuth, fallback inseguro, ContextVar nunca usado, etc. Análisis técnico detallado en Notion.	done	normal	\N	11	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3306d245-8bcb-8088-af74-da1c218335e0", "tadin_project": ["Backend"]}	2026-05-21 23:11:20.464117	2026-05-22 08:14:58.746449	\N	\N	\N
e3f5eeaa-93ea-495b-8003-24f43b054325	e44083dd-0913-4bb5-b107-afb978377446	\N	El error en el flujo de conversación del chat global	Dos problemas: 1) Error con las menciones (no funciona mencionar agentes). 2) Flujo de chat (cuando terminas de hablar con el agente redirigido el manager pierde el hilo).	done	urgent	\N	12	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3506d245-8bcb-80ed-8574-e05232979dff", "tadin_project": []}	2026-05-21 23:11:21.172927	2026-05-22 08:14:58.753075	\N	\N	\N
756d304e-bf14-4cac-83cd-b680d01b4fb3	e44083dd-0913-4bb5-b107-afb978377446	\N	Eliminar del marketplace las siguientes integraciones	- crear exel\n- crear pdf\n- editar exel	done	normal	\N	3	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-8030-8840-d247b9234c21", "tadin_project": []}	2026-05-21 23:11:14.802668	2026-05-22 08:14:58.690097	\N	\N	\N
7c91ad58-443d-4931-bbf2-a6581a299092	e44083dd-0913-4bb5-b107-afb978377446	\N	Mejorar UI Tools	Agregar un tool name visualmente correcto para el front\nagregar tool name y description en ingles y espanol	done	low	\N	5	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3176d245-8bcb-80c4-9c10-c8eeae5ebdc8", "tadin_project": []}	2026-05-21 23:11:15.547577	2026-05-22 08:14:58.704628	\N	\N	\N
94b7fafa-1808-4394-a5f1-71480b827071	e44083dd-0913-4bb5-b107-afb978377446	\N	Implementar CAK (Context-Aware Knowledge) en LangChain	Implementación de CAK (Context-Aware Knowledge) en LangChain. Sistemas de conocimiento que adaptan su representación y recuperación según el contexto actual.	backlog	high	2026-04-01	1	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3266d245-8bcb-81d3-9ff8-c850a557bbf8", "tadin_project": ["Backend"]}	2026-05-21 23:11:24.694184	2026-05-21 23:11:24.694211	\N	\N	\N
1c98ac95-5737-4f1a-8f59-55b13f974224	e44083dd-0913-4bb5-b107-afb978377446	\N	Cola de agente por provider	Hacer que los agentes esperen por las ejecuciones del resto. Agentes en la nube ejecuciones paralelas de 10, agentes con proveedores locales 1 en 1.	backlog	normal	\N	3	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3506d245-8bcb-801f-bb98-f413b0520a2e", "tadin_project": []}	2026-05-21 23:11:37.129538	2026-05-21 23:11:37.129562	\N	\N	\N
8878cc8d-6e8a-42aa-9c1c-206deceab9ed	e44083dd-0913-4bb5-b107-afb978377446	\N	Error al crear una instancia de wsapp con el builder	Se crea correctamente pero los contactos agregados en lista blanca/negra desde el builder no funcionan como filtros.	done	urgent	\N	1	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3566d245-8bcb-80bf-be52-f5f528c11347", "tadin_project": []}	2026-05-21 23:11:37.878265	2026-05-23 04:51:38.914428	\N	\N	\N
02508451-ff21-4883-bbf2-dc0ef63f7388	e44083dd-0913-4bb5-b107-afb978377446	\N	Sanear keys eliminando caracteres de mas al inicio y al final		done	normal	\N	6	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3656d245-8bcb-804a-b9db-e8a1d248593e", "tadin_project": []}	2026-05-21 23:11:25.332949	2026-05-24 04:10:38.146127	\N	\N	\N
9470bcdc-3002-4fa3-8688-483a465fced9	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar disparadores	- Webhook\n- File\n- Tiempo	done	normal	\N	14	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3176d245-8bcb-80b4-ab26-c13289e641c7", "tadin_project": ["Backend"]}	2026-05-21 23:11:22.500385	2026-05-22 08:14:58.768467	\N	\N	\N
c9167178-1aac-4b79-8095-b9599fe9a793	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar providers hardcodeados en el modal de crear agente		done	normal	\N	16	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3566d245-8bcb-80f2-8e0e-cf84643f50f1", "tadin_project": []}	2026-05-21 23:11:26.082455	2026-05-22 08:14:58.782937	\N	\N	\N
6a0c5d2b-d158-4647-bd18-0b607d214564	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar traducción a inglés	- Ventanas Efímeras	done	normal	\N	17	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3166d245-8bcb-8084-ada5-d9c64a1ff193", "tadin_project": ["Documentacón"]}	2026-05-21 23:11:26.834483	2026-05-22 08:14:58.789662	\N	\N	\N
aa19b18d-4b0c-4743-9629-5c067b624267	e44083dd-0913-4bb5-b107-afb978377446	\N	Traducir systempromts a inglés		done	low	\N	19	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-8024-bf25-c848d0896fac", "tadin_project": []}	2026-05-21 23:11:28.249744	2026-05-22 08:14:58.803547	\N	\N	\N
4c6b044a-f7b6-4943-ba98-56416125c989	e44083dd-0913-4bb5-b107-afb978377446	\N	Eliminar la vista avanzada		done	urgent	\N	20	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3176d245-8bcb-80bc-8d84-ccadee103ce7", "tadin_project": []}	2026-05-21 23:11:30.419148	2026-05-22 08:14:58.809938	\N	\N	\N
d641b717-a973-46fe-aa06-abaf0f035c60	e44083dd-0913-4bb5-b107-afb978377446	\N	Cantidad de documentos seleccionables al crear la base de datos	Cuando se crea la base de datos vectorial solo deja seleccionar un documento, debería permitir seleccionar varios.	done	normal	\N	21	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3646d245-8bcb-8092-9657-e77382c0518c", "tadin_project": []}	2026-05-21 23:11:33.427747	2026-05-22 08:14:58.816721	\N	\N	\N
799e9363-5930-4f0e-bebf-f40a6aacf210	e44083dd-0913-4bb5-b107-afb978377446	\N	Respuesta del agente invocado por disparador en el chat	Permitir que cuando el agente es invocado por el disparador responda al chat guardando el mensaje en el historial.	done	normal	\N	23	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "31e6d245-8bcb-80e9-b0f5-d47b21d791a0", "tadin_project": ["Backend"]}	2026-05-21 23:11:35.63656	2026-05-22 08:14:58.830479	\N	\N	\N
43dca3b0-ed8e-487f-a4fc-53db604c7cd4	e44083dd-0913-4bb5-b107-afb978377446	\N	Error durante la creación de oficinas con Tadiin helper	Cuando le das a crear una nueva oficina crea correctamente la oficina pero luego el builder agent crea los agentes en la oficina anterior.	done	normal	\N	24	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-8062-b1d7-e31c09f558fc", "tadin_project": []}	2026-05-21 23:11:36.383006	2026-05-22 08:14:58.836532	\N	\N	\N
3c757953-612e-4cde-a385-670c0da10e97	e44083dd-0913-4bb5-b107-afb978377446	\N	Cuando estas creando un agente con el builder no te selecciona la ApiKey del modelo que le vas a poner		done	normal	\N	45	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3656d245-8bcb-8011-85a1-d14b48c064c4", "tadin_project": []}	2026-05-21 23:11:34.844338	2026-05-22 08:14:58.683148	\N	\N	\N
12a78b26-88ae-4cad-b53b-ece1f81cb20a	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar el chat 2	El chat cuando se crea una nueva seción da errores aveces	done	normal	\N	13	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3176d245-8bcb-8062-ac41-f7851c4ba95f", "tadin_project": ["Frontend"]}	2026-05-21 23:11:21.878088	2026-05-22 08:14:58.76137	\N	\N	\N
f0dbb3e1-f966-44bc-a31d-8bbaa3a4c66d	e44083dd-0913-4bb5-b107-afb978377446	\N	Al crear un agente desde el chat de oficina, y cambias a la vista de equipo, se actualiza y no se ven los nuevos agentes		done	normal	\N	7	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3676d245-8bcb-80fb-9e06-f4bb36a1138b", "tadin_project": []}	2026-05-21 23:11:29.629816	2026-05-27 03:21:39.728072	\N	\N	\N
aafbdd9e-4957-42bc-aa95-f4e80e8494a5	e44083dd-0913-4bb5-b107-afb978377446	\N	Implementar la funcionalidad para desactivar el think en lm studio		backlog	normal	\N	4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-80b1-9b88-c2cf9e6095ec", "tadin_project": []}	2026-05-21 23:11:44.482145	2026-05-21 23:11:44.48217	\N	\N	\N
d2dbb8f0-bff0-48b2-94b2-e25c3e0a2155	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar validaciones a formularios de Agentes, Tools, Skills y MCP para evitar nombres duplicados	Implementar un sistema de validación que prevenga la creación o importación de elementos con nombres duplicados.	backlog	high	\N	5	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "32a6d245-8bcb-8101-bf2a-d8a217dfc805", "tadin_project": ["Backend"]}	2026-05-21 23:11:46.623608	2026-05-21 23:11:46.623634	\N	\N	\N
012eeb8d-dc7d-41a3-95f8-959334083f04	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar HITL a las conversaciones de los chats interagentes	Implementar un sistema de Human-in-the-Loop personalizado para las conversaciones de los chats interagentes.	backlog	normal	\N	6	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3286d245-8bcb-8107-8b07-d3e6c0eb55de", "tadin_project": ["Backend"]}	2026-05-21 23:11:49.553326	2026-05-21 23:11:49.553353	\N	\N	\N
d44f86de-47fa-4b72-8ea1-adfbeb0025e9	e44083dd-0913-4bb5-b107-afb978377446	\N	Optimizar el helper correctamente ante cualquier peticion	No existe actualmente una función para cambiar el modelo de un agente de trabajo existente. Las herramientas de office_manager solo permiten crear/mover/clonar/eliminar.	to_test	high	\N	5	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "35a6d245-8bcb-8031-b598-e396517ace36", "tadin_project": []}	2026-05-21 23:11:50.183584	2026-05-21 23:11:50.183605	\N	\N	\N
9cdb8c28-fcbc-4a1f-8a46-85ad6b8c7183	e44083dd-0913-4bb5-b107-afb978377446	\N	seguir el chat con un agente especifico en el chat de oficina	Cada vez que escribes por el chat de oficina te responda el manager, debería seguir la conversación con el agente objetivo.	done	normal	\N	26	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3516d245-8bcb-8061-a031-fdef847d5f4f", "tadin_project": []}	2026-05-21 23:11:39.459625	2026-05-22 08:14:58.848915	\N	\N	\N
fd4519d5-f261-4a29-a262-cab6682fb9a2	e44083dd-0913-4bb5-b107-afb978377446	\N	Sistema de scoring para decision a q agente delegar tareas		done	urgent	\N	27	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3346d245-8bcb-80b4-85ba-d41175472acc", "tadin_project": ["Backend"]}	2026-05-21 23:11:40.204103	2026-05-22 08:14:58.855166	\N	\N	\N
61647beb-8690-4db9-b91f-bbc1f3d014a4	e44083dd-0913-4bb5-b107-afb978377446	\N	Cuando se va a editar un agente no se ve ni la descripción ni el system promt		done	low	\N	28	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33c6d245-8bcb-80c8-a819-d477627cd20d", "tadin_project": []}	2026-05-21 23:11:40.956305	2026-05-22 08:14:58.86188	\N	\N	\N
42cb8560-2f39-4336-8c11-31306a1a1038	e44083dd-0913-4bb5-b107-afb978377446	\N	mientras el agente esta estrimeando no se puede hacer scroll hacia arriba		done	normal	\N	29	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3186d245-8bcb-806e-bd63-c4258409a8d7", "tadin_project": []}	2026-05-21 23:11:41.665748	2026-05-22 08:14:58.868534	\N	\N	\N
76213fa5-65bd-4d01-af55-8939ad83a4d5	e44083dd-0913-4bb5-b107-afb978377446	\N	Implementar tools como modulos		done	high	2026-02-28	30	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-80c7-a260-cf90f21e4408", "tadin_project": []}	2026-05-21 23:11:42.418595	2026-05-22 08:14:58.874644	\N	\N	\N
f65cd435-eea0-4854-9ef9-b1c27ec896ba	e44083dd-0913-4bb5-b107-afb978377446	\N	Implementar OpenRouter como provider		done	high	2026-02-28	31	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-8020-a795-c3e5b79e3e2a", "tadin_project": []}	2026-05-21 23:11:43.850743	2026-05-22 08:14:58.880883	\N	\N	\N
76b895bf-14ed-48a9-b4f9-afb5de5be5fb	e44083dd-0913-4bb5-b107-afb978377446	\N	Implementar funcion para cambiar agentes de oficina		done	normal	\N	32	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-80c2-98e9-e0f28bbfb766", "tadin_project": []}	2026-05-21 23:11:45.826226	2026-05-22 08:14:58.88758	\N	\N	\N
adafe8d4-99d5-49ca-824d-e237071b9c57	e44083dd-0913-4bb5-b107-afb978377446	\N	Mejorar herramienta pdf que permita edicion y lectura		done	high	\N	33	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3346d245-8bcb-8088-ab71-fbb57f0bbd81", "tadin_project": ["Tools"]}	2026-05-21 23:11:47.331583	2026-05-22 08:14:58.894095	\N	\N	\N
11e32319-774e-4b97-9aef-cec2cafd3920	e44083dd-0913-4bb5-b107-afb978377446	\N	Ajustes en la UI para streaming en preview de agentes (Sidebar)	Implementar ajustes en la interfaz para permitir la visualización del streaming en la vista previa de los agentes.	done	normal	2026-03-23	34	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "32c6d245-8bcb-815e-ab3a-e108612cf3cf", "tadin_project": []}	2026-05-21 23:11:48.124816	2026-05-22 08:14:58.901495	\N	\N	\N
9a263964-0b5f-46ca-9098-585809bd7818	e44083dd-0913-4bb5-b107-afb978377446	\N	Mejorar la vista del panel lateral para que se vean mas humanos		done	normal	\N	35	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "32c6d245-8bcb-80e3-90a3-fae10130ee91", "tadin_project": ["Frontend"]}	2026-05-21 23:11:48.925236	2026-05-22 08:14:58.908184	\N	\N	\N
9d878b91-7650-4964-a565-4bd9d2999442	e44083dd-0913-4bb5-b107-afb978377446	\N	Adaptar el contexto del helper a la localización del usuario	El helper debe ser capaz de identificar en que oficina se encuentra para trabajar sobre ella.	done	normal	\N	36	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3516d245-8bcb-8086-beb2-d9fd2ed1c494", "tadin_project": []}	2026-05-21 23:11:50.813578	2026-05-22 08:14:58.915354	\N	\N	\N
776db74d-634b-416e-9f2d-f90fded0094c	e44083dd-0913-4bb5-b107-afb978377446	\N	Exportar sin credenciales	Cuando se exporte una oficina esta se debe exportar sin credenciales.	done	normal	\N	37	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3556d245-8bcb-80e7-a998-f20172353a51", "tadin_project": []}	2026-05-21 23:11:51.612293	2026-05-22 08:14:58.922405	\N	\N	\N
408760a1-b486-4ed4-902c-3526233e9781	e44083dd-0913-4bb5-b107-afb978377446	\N	Problema de redirección al crear una nueva oficina manual	Cuando se crea una nueva oficina redirige al chat global. Debe redirigir a la pestaña de equipo.	done	urgent	\N	38	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3516d245-8bcb-8084-82a1-c8fed1aec479", "tadin_project": []}	2026-05-21 23:11:52.362313	2026-05-22 08:14:58.929247	\N	\N	\N
16cec1ae-42f9-4391-ab8e-93810a0bb976	e44083dd-0913-4bb5-b107-afb978377446	\N	Adaptar el helpera a abierto por defecto	El helper debe estar abierto por defecto, no debe superponerse, debe ser chat lateral, debe sacar nube de diálogo cuando minimizado.	done	urgent	\N	39	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3516d245-8bcb-8074-bf9e-ebcff16651cd", "tadin_project": []}	2026-05-21 23:11:53.822187	2026-05-22 08:14:58.93792	\N	\N	\N
1c51a682-8978-41c8-9ab3-dbf6e5060131	e44083dd-0913-4bb5-b107-afb978377446	\N	Salas de chat	Agregar salas de chat funcionales. Agregar funcionalidad de importar y exportar salas de chat.	done	high	\N	40	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3346d245-8bcb-80ee-b1f4-f5450d590d4c", "tadin_project": ["Backend", "Frontend"]}	2026-05-21 23:11:54.624152	2026-05-22 08:14:58.946676	\N	\N	\N
1299f8cd-8569-4293-ba1e-dd55990b65e4	e44083dd-0913-4bb5-b107-afb978377446	\N	El agente constructor en el formulario no selecciona la credencial del proveedor LLM	Cuando estas en el paso de seleccionar el modelo el agente constructor no selecciona la apikey del proveedor.	to_test	normal	\N	10	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3646d245-8bcb-80e2-a507-cc645c0f02e3", "tadin_project": []}	2026-05-21 23:11:32.673997	2026-05-23 02:13:13.682546	\N	🐛	\N
6361eefe-7be4-42a8-8ee4-c9a6d690c034	e44083dd-0913-4bb5-b107-afb978377446	\N	Error en las seciones de chat	El sistema que crea las sesiones está calculando el nuevo ID basándose en la cantidad de sesiones activas, causando colisión de IDs.	done	high	\N	25	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3166d245-8bcb-80a4-a534-d54d95296ad7", "tadin_project": ["Backend"]}	2026-05-21 23:11:38.668863	2026-05-22 08:14:58.843134	\N	\N	\N
8a9c77cc-e343-4e74-857a-557fb150cc9f	e44083dd-0913-4bb5-b107-afb978377446	\N	traits	Agregar soporte de traits	backlog	normal	\N	7	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-807a-a05c-c468b377ed93", "tadin_project": []}	2026-05-21 23:22:29.39909	2026-05-21 23:22:29.399108	\N	\N	\N
a8631421-09bb-4906-8775-b6ded5daa3a0	e44083dd-0913-4bb5-b107-afb978377446	\N	Coordinar la funcionalidad del enjambre en el chat global	Colocar propuestas aqui	done	high	\N	43	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-8088-b82a-cdbbcc356540", "tadin_project": ["Frontend"]}	2026-05-21 23:11:56.658094	2026-05-22 08:14:58.97176	\N	\N	\N
f2c84d5d-229d-4ee3-abdb-526272657aca	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar seleccionar tools en crear agente	Unificar todas las tools, skills, mcp, como una misma cosa\n\nEliminar el filesystem y code execute	not_started	normal	\N	2	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3566d245-8bcb-80da-b971-fa2676eb467e", "tadin_project": []}	2026-05-21 23:11:10.858588	2026-05-22 05:05:47.294356	\N	\N	\N
4f1c028a-bea9-41d7-a430-eb71c278b3b3	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar la skill de eliminar agentes		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33d6d245-8bcb-80e8-83ed-d375b289c4bb", "tadin_project": []}	2026-05-22 14:14:45.624371	2026-05-22 14:14:45.624388	\N	\N	\N
448f036a-bdb8-46c3-8e6c-ea35d85ebb53	e44083dd-0913-4bb5-b107-afb978377446	\N	Refactorizción del plan de creación de la oficina	El plan no debe estar aislado del chat, debe estar dentro y aceptarse textualmente como una pregunta más.	done	high	\N	44	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3516d245-8bcb-8052-8917-cf5de4c68f5a", "tadin_project": []}	2026-05-21 23:11:57.41843	2026-05-22 08:14:58.977991	\N	\N	\N
050db125-a8dd-45e4-b5a3-742bb013e386	e44083dd-0913-4bb5-b107-afb978377446	\N	Cambios de accesibilidad y visibilidad en el frontend	Principales Ideas:\n- [x] Cambiar la barra de gestion de agentes en el chat general a una barra lateral\n- [x] Agregar la opcion de colapsar la sidebar\n- [x] Eliminar los placeholder de la seleccion de modelos de la opcion de local en la vista de crear un agente\n- [x] Ayudar al usuario con el paso a paso de crear un agente en la vista simple\n- [x] Agregar mas opciones de personalizacion para el agente como mas iconos y la posibilidad de elegir un color	done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-80ba-9183-edc697a6013a", "tadin_project": []}	2026-05-22 14:14:45.564406	2026-05-22 14:14:45.564431	\N	\N	\N
b2c6e14c-18c3-4650-a513-e697f7abcd8c	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar la think bubble de los modelos con thinking		done	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-80f4-b8f2-c1f212248c45", "tadin_project": []}	2026-05-22 14:14:45.579085	2026-05-22 14:14:45.579112	\N	\N	\N
c7344611-467a-461c-ab4f-65d0fec690ad	e44083dd-0913-4bb5-b107-afb978377446	\N	Tools de channels no se exponen al agente en su chat directo		done	normal	\N	15	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{}	2026-05-24 02:42:58.212665	2026-05-27 03:38:13.663445	\N	\N	\N
822a4964-6538-4e1b-8a3e-88d618ed04ff	e44083dd-0913-4bb5-b107-afb978377446	\N	skills	Agregar soporte de skills	done	normal	\N	45	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-803e-b533-f51c1bbc7274", "tadin_project": []}	2026-05-21 23:22:28.597259	2026-05-22 08:14:58.984825	\N	\N	\N
6b9d3b05-11d8-4e21-8ff7-04c3f015140c	e44083dd-0913-4bb5-b107-afb978377446	\N	Refactorización de los MCP	\nLos MCP deben poder gestionar más de una credencial  y durante la craón de agentes por formulario debe poder seleccionar una credencial de las que tenga agregada el mcp .	error	normal	\N	16	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-24 03:11:18.713776	2026-05-24 03:11:18.713801	\N	\N	\N
059cbad3-21fc-49a0-a217-33f4d3b0a250	e44083dd-0913-4bb5-b107-afb978377446	\N	Durante la creación de los agentes seleccion del modelo	Cuando el agente de creación decide que el modelo debe ser de un proveedor X te pide directamente la apikey. Agregar en el flujo que el agente te permita seleccionar un proveedor que ya tienes.	done	normal	\N	6	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-8084-953a-c7ce596abd2d", "tadin_project": []}	2026-05-21 23:11:16.218115	2026-05-22 08:14:58.711451	\N	\N	\N
99d9624b-b040-41c2-9cb9-f86db2f206f2	e44083dd-0913-4bb5-b107-afb978377446	\N	Actualización de creación de la oficina	En el formulario la oficina debe tener: Nombre, Descripción, Contexto. Dos botones al final: amarillo para guardar y salir, verde para guardar y pasar al formulario de agentes.	done	high	\N	42	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3516d245-8bcb-8050-82fb-e0bc715a3ff6", "tadin_project": []}	2026-05-21 23:11:55.984992	2026-05-22 08:14:58.962992	\N	\N	\N
52929b0b-aeb1-4699-ab7b-fa9b7991d811	e44083dd-0913-4bb5-b107-afb978377446	\N	Actualización de la vista de crear agentes	El campo especialidad debe admitir al menos 700 caracteres (funciona como system prompt). Debajo del nombre del agente solo deben salir los primeros 40 caracteres del campo especialidad. Asegurarse de que sea responsive.	done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3166d245-8bcb-801c-9131-da51c4095cac", "tadin_project": []}	2026-05-22 14:14:45.58278	2026-05-22 14:14:45.582797	\N	\N	\N
d1e3fffb-69b4-424e-bbce-c42fa75ff5d4	e44083dd-0913-4bb5-b107-afb978377446	\N	Error en el provider de open router	mas info en el backend pending	done	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3166d245-8bcb-807e-a743-df631e7b0bb9", "tadin_project": []}	2026-05-22 14:14:45.585754	2026-05-22 14:14:45.585771	\N	\N	\N
2458e663-fd49-4d53-8506-75291fa69fa9	e44083dd-0913-4bb5-b107-afb978377446	\N	Permitir que en windows se puedan agregar las tools		backlog	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "31e6d245-8bcb-80d5-9a60-d4190d6450e8", "tadin_project": []}	2026-05-22 14:14:45.595659	2026-05-22 14:14:45.595688	\N	\N	\N
1a95f8a3-fea9-405f-9fb8-a3a10a8d369e	e44083dd-0913-4bb5-b107-afb978377446	\N	Probar extensiones soportadas por el uploader de la tab de conocimientos	Probar las extensiones de archivo soportadas por el uploader de la pestaña de conocimientos, verificando que cada parser funcione correctamente y que la estrategia de chunking se aplique adecuadamente.\n\nExtensiones: .pdf (pypdf), .doc/.docx (python-docx), .pptx (python-pptx), .odt (odfpy), .rtf (striprtf), .xls (xlrd), .xlsx (openpyxl), .csv (stdlib csv), .html/.htm (beautifulsoup4), .json (stdlib json), .xml (stdlib xml), .txt/.md/.mdx (UTF-8 directo).	done	urgent	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "32d6d245-8bcb-81b0-b4e7-da8afc371476", "tadin_project": ["Documentacón"]}	2026-05-22 14:14:45.608472	2026-05-22 14:14:45.60849	\N	\N	\N
fc6e0ebe-3971-45a1-8767-e423f9da7c10	e44083dd-0913-4bb5-b107-afb978377446	\N	Documentar todas las integraciones de tools_to_import	Crear documentación completa para las 17 integraciones existentes en `/home/luis/Chat_Agents_Project/tadin-service/tools_to_import/`. El README actual menciona 3 herramientas que no existen (get_current_datetime, telegram_integration, telegram_webhook_agent_integration). Progreso: 10/17 documentadas (59%).	backlog	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3336d245-8bcb-813c-9aad-cb9cabee30dc", "tadin_project": ["Documentacón"]}	2026-05-22 14:14:45.61145	2026-05-22 14:14:45.611473	\N	\N	\N
8ab0d158-7244-4235-91ca-15a8e3415385	e44083dd-0913-4bb5-b107-afb978377446	\N	Integracion con Odoo	Crear o instalar un módulo en Odoo que se conecte a un agente externo (IA, automatización, bot, API) usando MCP. Ejemplos: agente analiza ventas y recomienda precios, bot que responde tickets, agente que sincroniza inventario, asistente de IA dentro de Odoo.	backlog	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3356d245-8bcb-80d1-ac12-ecaf02155e49", "tadin_project": ["Tools"]}	2026-05-22 14:14:45.615522	2026-05-22 14:14:45.615539	\N	\N	\N
a878d92c-457d-4cfb-9bbf-10811a4c7bc5	e44083dd-0913-4bb5-b107-afb978377446	\N	No se guardan los cambios en la configuración de la oficina (El modelo del manager)		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-8097-9c72-dd3fec9d1fb3", "tadin_project": []}	2026-05-22 14:14:45.620264	2026-05-22 14:14:45.620306	\N	\N	\N
65376f1e-1ea4-45fd-a2cb-9ae380ddcf89	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar los estilos según el estilo seleccionado en las configuraciones		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3446d245-8bcb-8038-8e69-fc42125182e6", "tadin_project": []}	2026-05-22 14:14:45.628175	2026-05-22 14:14:45.628199	\N	\N	\N
62f8d489-4072-4fba-9360-d6eafa8973ff	e44083dd-0913-4bb5-b107-afb978377446	\N	Hacer que funcione el panel de la parte inferior de la oficina		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3446d245-8bcb-808f-a361-e0fecab4ffcc", "tadin_project": []}	2026-05-22 14:14:45.632934	2026-05-22 14:14:45.632958	\N	\N	\N
af76edaf-c9bc-46a0-a2fa-8bb379d1effb	e44083dd-0913-4bb5-b107-afb978377446	\N	Hacer que las bases de conocimiento funcionen por oficina	- Solo para la oficina\n- No sean visibles ni utilizables en el resto de las oficinas	done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3446d245-8bcb-80c7-ac40-c676c33ef272", "tadin_project": []}	2026-05-22 14:14:45.635061	2026-05-22 14:14:45.635077	\N	\N	\N
f9868316-f2d4-43da-a5ff-9a8546e302af	e44083dd-0913-4bb5-b107-afb978377446	\N	Hacer que se carguen una sola vez todos los agentes del frontend	Para que no se haga una consulta al backend cada vez que se cambie de oficina.	done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3446d245-8bcb-80d2-8d87-d204dcd0b933", "tadin_project": []}	2026-05-22 14:14:45.637127	2026-05-22 14:14:45.637151	\N	\N	\N
c79f9dba-8aca-43e2-a1ea-768724780e07	e44083dd-0913-4bb5-b107-afb978377446	\N	Telegram no deja actualizar	Cuando actualizas una instancia de telegram se desconecta y no deja conectarla de nuevo.	done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3556d245-8bcb-804c-8e00-ef151e4278b4", "tadin_project": []}	2026-05-22 14:14:45.643333	2026-05-22 14:14:45.643356	\N	\N	\N
369dba62-8298-4e4e-91e7-8aebd12e54a5	e44083dd-0913-4bb5-b107-afb978377446	\N	No funciona la lista blanca de wsapp si se agrega el contacto dando click	Solo funciona si se agrega el contacto manualmente.	done	normal	\N	46	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "35d6d245-8bcb-8065-88d4-d2a7fcbc17b0", "tadin_project": []}	2026-05-22 14:14:45.649445	2026-05-23 05:10:31.162096	\N	\N	\N
f98ddb21-94ad-4193-9d85-a6f783a36089	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar el manager con respecto a las tools en los chat y quitarle el chat privado		not_started	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "35d6d245-8bcb-8098-b8d5-e97255e8189b", "tadin_project": []}	2026-05-22 14:14:45.651893	2026-05-22 14:14:45.651926	\N	\N	\N
5f139966-ee4c-4ca3-a4e5-7a09a38ae353	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglado modal de las bases de conocimiento (multi-doc en segundo plano)	Ahora desde la oficina se puede ver cómo va la subida de docs y se queda en segundo plano (antes se cancelaba al salir de las vistas).	done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3656d245-8bcb-8088-8ba0-de4ba961fe0f", "tadin_project": []}	2026-05-22 14:14:45.65641	2026-05-22 14:14:45.656435	\N	\N	\N
5a3865a9-9bc4-4fe7-b163-d2a931332bbc	e44083dd-0913-4bb5-b107-afb978377446	\N	Permitir q el helper se cambie provider y modelo		not_started	normal	\N	11	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Backend", "Frontend"]}	2026-05-22 14:25:20.675001	2026-05-22 14:25:20.675019	\N	\N	\N
05462b10-4ecc-409a-8533-52b296ae232e	e44083dd-0913-4bb5-b107-afb978377446	\N	Navegador web de agentes		backlog	low	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33d6d245-8bcb-80d4-9acc-ebda9c6805d6", "tadin_project": []}	2026-05-22 14:27:56.731531	2026-05-22 14:27:56.731551	\N	\N	\N
9070284a-6cde-4103-8b52-ec3f96899061	e44083dd-0913-4bb5-b107-afb978377446	\N	Editar mcps en agentes con el builder		not_started	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33e6d245-8bcb-8072-9874-dcf0b2fc9cef", "tadin_project": []}	2026-05-22 14:27:56.740782	2026-05-22 14:27:56.740807	\N	\N	\N
ac1317d8-db93-4152-b4bd-f2d3e158650d	e44083dd-0913-4bb5-b107-afb978377446	\N	Integrar el formulario de creación de agentes de la nueva interfaz		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3456d245-8bcb-8074-bbe3-c0c158d8739b", "tadin_project": []}	2026-05-22 14:27:56.747238	2026-05-22 14:27:56.747256	\N	\N	\N
4bb488ba-ffe8-41de-a475-3cc6a4278e52	e44083dd-0913-4bb5-b107-afb978377446	\N	Añadir deepseek como provider		done	urgent	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3176d245-8bcb-80ec-b91d-dba2e5c14385", "tadin_project": []}	2026-05-22 14:27:56.749643	2026-05-22 14:27:56.749671	\N	\N	\N
0e4f2488-6f45-4765-8de8-35642e308f54	e44083dd-0913-4bb5-b107-afb978377446	\N	Problema al conversar con los agentes	Error: ModularAgent.__init__() got an unexpected keyword argument 'triggers'	done	urgent	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33d6d245-8bcb-8071-8a1a-fef8f0fd6d17", "tadin_project": []}	2026-05-22 14:27:56.753328	2026-05-22 14:27:56.753353	\N	\N	\N
a9e3731f-4f85-4578-ad79-bd21013a069b	e44083dd-0913-4bb5-b107-afb978377446	\N	No se guarda la configuración de las oficinas		done	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-809d-b7f0-dfc4181b1b5d", "tadin_project": []}	2026-05-22 14:27:56.756625	2026-05-22 14:27:56.756652	\N	\N	\N
6edd2329-5f48-4c33-b920-47707d528f72	e44083dd-0913-4bb5-b107-afb978377446	\N	Hay un despagine en la comprención de rutas de los agentes 	envié una imagen por el chat gloval  y un agente comenzo a buscar en home david (cuando los agentes estan en un sanbox ) al final termin encontrando la imagen en (app/sessions/.../user_docs)\n\nrespuesta del agente al buscar una imagen :\n\n📷 Screenshot.png\nPropiedad\tValor\nFormato\tPNG válido ✅\nTamaño\t170.8 KB\nDimensiones\t1920 × 1080 px (Full HD)\nProfundidad\t8 bits por canal\nTipo de color\tRGBA (Color verdadero con canal alfa)\nUbicación alternativa\tEstaba en /app/sessions/.../user_docs/ (no en /home/david/...)	error	normal	\N	17	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-24 03:21:11.886438	2026-05-24 03:34:23.117594	\N	\N	\N
1ca49def-3828-45e9-9428-b6b835d10d3e	e44083dd-0913-4bb5-b107-afb978377446	\N	No me funcionan los disparadores para invocar agentes	Error en backend: trigger.action.failed action=invoke_agent error="404: Agent not found"	done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "31e6d245-8bcb-8068-922a-ce9d6454d379", "tadin_project": ["Backend"]}	2026-05-22 14:27:56.762961	2026-05-22 14:27:56.762989	\N	\N	\N
b26688e7-6c10-461d-b16a-99714f32f028	e44083dd-0913-4bb5-b107-afb978377446	\N	Thinking remote providers		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Backend"]}	2026-05-22 14:33:42.471329	2026-05-22 14:33:42.471353	\N	\N	\N
59d31739-af97-4637-954d-e8aaa9e27825	e44083dd-0913-4bb5-b107-afb978377446	\N	Provider HugginFace		backlog	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.479724	2026-05-22 14:33:42.479747	\N	\N	\N
803def6e-79f2-4ff1-96c8-0fa32d1fe22d	e44083dd-0913-4bb5-b107-afb978377446	\N	thinking no se muestra en deepagent		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Backend"]}	2026-05-22 14:33:42.482774	2026-05-22 14:33:42.4828	\N	\N	\N
785402d5-698e-4029-9124-b208a70b5c69	e44083dd-0913-4bb5-b107-afb978377446	\N	al recargar un chat no se mantiene el flujo actual del websocket		done	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.485426	2026-05-22 14:33:42.485451	\N	\N	\N
5e7b9edd-8b2f-4b0f-b1a3-734b299bf828	e44083dd-0913-4bb5-b107-afb978377446	\N	arrglar think bubble infinita		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Backend"]}	2026-05-22 14:33:42.488701	2026-05-22 14:33:42.488724	\N	\N	\N
bea1841e-04c5-4646-a48b-8087526ba5c0	e44083dd-0913-4bb5-b107-afb978377446	\N	Validar funcionalidades de los triggers		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.491319	2026-05-22 14:33:42.491344	\N	\N	\N
def4d096-d323-4617-875c-de8ed0e607e7	e44083dd-0913-4bb5-b107-afb978377446	\N	Permitir que el usuario pueda agragar mas de una tool a la vez		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Backend"]}	2026-05-22 14:33:42.493717	2026-05-22 14:33:42.493739	\N	\N	\N
4ae085c4-80df-4f40-82f3-e16a3cbf6bf1	e44083dd-0913-4bb5-b107-afb978377446	\N	Al crear un disparador e intentar editarlo este no se actualiza		done	urgent	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.496692	2026-05-22 14:33:42.496717	\N	\N	\N
f83a8762-3faf-4be2-8ff7-133e5505b24f	e44083dd-0913-4bb5-b107-afb978377446	\N	LMS no me funciona en windows a la hora de hacer consultas		backlog	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.499165	2026-05-22 14:33:42.499182	\N	\N	\N
e10b044b-7530-481f-84e0-e5c321fb0648	e44083dd-0913-4bb5-b107-afb978377446	\N	sumarization middleware se rompe		done	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.501541	2026-05-22 14:33:42.501568	\N	\N	\N
fa1f7a4b-722b-4114-863e-8be04c3202f6	e44083dd-0913-4bb5-b107-afb978377446	\N	Configurar integraciones en lenguaje natural		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Backend"]}	2026-05-22 14:33:42.503453	2026-05-22 14:33:42.503476	\N	\N	\N
24b9d6c5-641f-4d6a-8385-3dceeb2d8483	e44083dd-0913-4bb5-b107-afb978377446	\N	Las notificaciones salen dobles para las integraciones		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Backend"]}	2026-05-22 14:33:42.505955	2026-05-22 14:33:42.50598	\N	\N	\N
f8c08c90-e266-4bf6-bc5b-0117db1609c7	e44083dd-0913-4bb5-b107-afb978377446	\N	Testing del marketplace		backlog	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.508436	2026-05-22 14:33:42.508461	\N	\N	\N
ec4ea125-0cda-4139-81a5-a591178d9e81	e44083dd-0913-4bb5-b107-afb978377446	\N	unificar las herramientas de Exel y agregar la lectura		done	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Tools"]}	2026-05-22 14:33:42.510302	2026-05-22 14:33:42.510328	\N	\N	\N
f367d804-e223-468f-86e9-788fc80da059	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar la funcionalidad de importar y exportar agentes		done	urgent	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.512755	2026-05-22 14:33:42.51278	\N	\N	\N
a71eb9cc-e09f-42a5-a057-8ae9cc0bcac7	e44083dd-0913-4bb5-b107-afb978377446	\N	Herramienta Word no permite crear estilos (ejemplo dar color a las letras escribir italica etc)		done	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Tools"]}	2026-05-22 14:33:42.517481	2026-05-22 14:33:42.517507	\N	\N	\N
ef1d7a95-16ed-4b11-afb7-24104d9360a6	e44083dd-0913-4bb5-b107-afb978377446	\N	Plugins de antropic		done	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": ["Backend", "Frontend"]}	2026-05-22 14:33:42.519904	2026-05-22 14:33:42.519929	\N	\N	\N
742de7b0-1520-4a71-8a56-87c35d321843	e44083dd-0913-4bb5-b107-afb978377446	\N	No funciona la lista blanca de wsapp si se agrega el contacto dando click solo funciona si se agrega el contacto manual		done	normal	\N	47	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.562256	2026-05-23 05:10:31.951306	\N	\N	\N
22a1ca42-4f18-440b-9deb-0eee911b78ee	e44083dd-0913-4bb5-b107-afb978377446	\N	Error durante la creación de oficinas con Tadiin helper (A la hora de crear agentes)		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.525081	2026-05-22 14:33:42.525104	\N	\N	\N
a7e106ba-134c-484b-ad4a-3382e7d818ba	e44083dd-0913-4bb5-b107-afb978377446	\N	No se guardan los cambios en la configuración de canal de wsapp LEER DESCRIPCIÓN		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.529006	2026-05-22 14:33:42.529027	\N	\N	\N
e6e639c5-0ff5-42f7-aaaf-bbb0e93cf63e	e44083dd-0913-4bb5-b107-afb978377446	\N	Cuando el helper te pasa con el builder que te va creando los agentes te dejaba el prompt de todos vacio (Arreglado)		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.56658	2026-05-24 02:48:44.605695	\N	\N	\N
ebfab4f7-bef2-406d-9758-af9dd0404168	e44083dd-0913-4bb5-b107-afb978377446	\N	Hacer que las bases de conocimiento funcionen de la siguiente forma		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.53253	2026-05-22 14:33:42.532551	\N	\N	\N
605224d9-6d10-4982-a459-f87cf68fa1c7	e44083dd-0913-4bb5-b107-afb978377446	\N	Hacer que los triguers (Automatizaciones) se vean solo en las oficinas donde estan asignados		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.535491	2026-05-22 14:33:42.535513	\N	\N	\N
9e97d043-30b6-4f1f-88f6-cf62883f8933	e44083dd-0913-4bb5-b107-afb978377446	\N	cuando estoy agregando la credencial de google al poner el nombre cada vez que pongo una letra me desmarca el imput		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.564201	2026-05-24 02:49:04.152175	\N	\N	\N
308ca1aa-0101-4c9d-a6f9-3861eb468848	e44083dd-0913-4bb5-b107-afb978377446	\N	Hacer que se carguen una sola vez todos los agentes del frontend para que no se haga una consulta al backend cada vez que se cambie de oficina		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.54342	2026-05-22 14:33:42.543449	\N	\N	\N
f76a30ef-033d-411f-8956-ffae22f8de50	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar visor de imagenes en tadiin 	En el chat de la aplicación las imagenes cuandose les da click lo que hacen es ponerse un poquito mas grande perosiguen sin verse bien \n\nagregar la funcionalidad de que cuando se le de click a una imagen se ponga en un modal mucho mas grande con la maxima resolución posible como mismo lo hce wsapp 	not_started	normal	\N	13	56f1614d-e66d-4d93-b090-33e03c34d084	{}	2026-05-24 03:36:50.906658	2026-05-24 03:36:50.906684	\N	\N	\N
25acd830-8c50-4c8d-a2b2-71b7368a6e7d	e44083dd-0913-4bb5-b107-afb978377446	\N	El todoolist de la construcción de oficinas no se actualiza coando el builder termina de crear los agentes		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.548894	2026-05-22 14:33:42.548911	\N	\N	\N
098d5599-9d51-4f3a-a44c-eee98cf3b3a2	e44083dd-0913-4bb5-b107-afb978377446	\N	Añadir funcionalidades de importar oficinas del marketplace al helper		in_progress	low	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.551637	2026-05-22 14:33:42.551665	\N	\N	\N
f5923117-6d4b-40d7-85bf-b6bc6f6f2af2	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar credenciales de herramientas a las oficinas importadas (Ver en equipo como simplificar la importación de la oficina )		in_progress	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.553353	2026-05-22 14:33:42.553369	\N	\N	\N
0bd14e57-12f6-4f4a-8c49-6d4591b2c20e	e44083dd-0913-4bb5-b107-afb978377446	\N	Categorias y esa boberia en el marketplace		not_started	urgent	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.555836	2026-05-22 14:33:42.555853	\N	\N	\N
6cbe5e8b-00a3-4fc0-8a00-7d9408280643	e44083dd-0913-4bb5-b107-afb978377446	\N	En los canales de wsapp cuando agregas un contacto a la lista blanca selecccionando el contacto en lugar de escribir el numero , no funciona (sigue sin responder al usuario )		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.558628	2026-05-22 14:33:42.558645	\N	\N	\N
b8b17bfa-18e2-4607-9b98-fe44ea8ac118	e44083dd-0913-4bb5-b107-afb978377446	\N	Al actualizar una instancia de telegram vuelve a pedir el token del bot	Cuando se va a actualizar una instancia de telegram vuelve a pedir el token del bot.\n\nComportamiento esperado: al actualizar, el campo de token debe estar relleno con un valor falso (* por ejemplo); si ese valor llega al backend no se actualiza el token; si el usuario cambia el valor a uno distinto del predefinido, entonces sí se actualiza.	done	normal	\N	9	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3646d245-8bcb-807d-904e-e16ef2bca770", "tadin_project": []}	2026-05-22 14:14:45.653736	2026-05-24 04:06:25.545339	\N	\N	\N
48b4fd9b-71e7-4717-902b-e03a77f10889	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglado modal de las bases de conocimiento que no subia mas de un doc, ahora desde la oficina puedes ver como va la subida de los doc y se queda en segundo plano ,antes se cancelaba al salir de las vistas		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_project": []}	2026-05-22 14:33:42.567966	2026-05-22 14:33:42.567982	\N	\N	\N
cf087882-5016-4a89-a610-a98a72a79417	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar descripción a los mcp , y que el agente reciba esta descripción		done	urgent	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3346d245-8bcb-802e-b18f-f64fac4de52e", "tadin_project": ["Backend"]}	2026-05-22 14:14:45.61363	2026-05-24 03:14:58.376725	\N	\N	\N
6b0bc0a8-50bc-4842-86ec-c339a33ce819	e44083dd-0913-4bb5-b107-afb978377446	\N	Integrar la Ai Ofice de cada oficina	- [x] Agregar la Ai Office a todas las oficinas\n- [ ] Hacer que los agentes reaccionen ante eventos	backlog	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3446d245-8bcb-804a-bbe5-d8ea3b1857be", "tadin_project": []}	2026-05-22 14:14:45.630706	2026-05-24 22:33:35.467257	\N	\N	\N
1b450e94-25fb-4058-8dad-7a9c276e3964	e44083dd-0913-4bb5-b107-afb978377446	\N	No se guardan los cambios en la configuración de canal de wsapp LEER DESCRIPCIÓN	En lugar de guardarse el cambio se crea una nueva instancia. Las instancias hay que mantenerlas, pero se deben configurar independiente cada una.	done	normal	\N	15	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33d6d245-8bcb-8010-a9dd-c2a8d6e9de89", "tadin_project": []}	2026-05-21 23:11:23.924038	2026-05-22 08:14:58.775293	\N	\N	\N
11cb856f-679f-47a8-9583-069cf8f73c08	e44083dd-0913-4bb5-b107-afb978377446	\N	Planificar instalación automatica del entorno aislado.	Crear un plan y programar las funciones necesarias para que instalar un entorno aislado se de forma automática.	done	normal	\N	18	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33a6d245-8bcb-80c1-8d05-fdcfef35b16a", "tadin_project": []}	2026-05-21 23:11:27.585311	2026-05-22 08:14:58.796127	\N	\N	\N
175fd510-ddb1-4e7e-8b62-7f0a113156ab	e44083dd-0913-4bb5-b107-afb978377446	\N	SI mientras se esta subiendo un documento se le asigna la base de conocimiento a un agente se deja de subirel documento	Error silencioso, el documento simplemente deja de subirse.	done	normal	\N	22	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3646d245-8bcb-8030-8e8c-ed243bd8f4e5", "tadin_project": []}	2026-05-21 23:11:34.220844	2026-05-22 08:14:58.823856	\N	\N	\N
5bd159e4-746c-4f1b-bce7-d91c7ddae768	e44083dd-0913-4bb5-b107-afb978377446	\N	arreglar los estilos de la vista de crear disparadores		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "32b6d245-8bcb-80c8-b51b-d62581077cbc", "tadin_project": []}	2026-05-22 14:14:45.599027	2026-05-22 14:14:45.599054	\N	\N	\N
0f02c8ce-fa8f-490d-98ed-c1f02a6c361e	e44083dd-0913-4bb5-b107-afb978377446	\N	eliminar degradado de los botones		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "32b6d245-8bcb-80f0-a87e-c5ca5ae81dc9", "tadin_project": []}	2026-05-22 14:14:45.602682	2026-05-22 14:14:45.602711	\N	\N	\N
cd4a7ef9-4951-4c9d-90fa-7cc702c2c7d6	e44083dd-0913-4bb5-b107-afb978377446	\N	mandar a alguien a quitar npm de skills		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "32b6d245-8bcb-80f3-add8-f193e27ad2cc", "tadin_project": []}	2026-05-22 14:14:45.605764	2026-05-22 14:14:45.606052	\N	\N	\N
11771a27-830f-474e-85d2-8bdf0caabfdc	e44083dd-0913-4bb5-b107-afb978377446	\N	Optimizacion del chat	Que carguen de 10 en 10 los mensajes para mejor rendimiento en el frontend	in_progress	high	\N	3	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3356d245-8bcb-8025-88a8-f5d1b50a0fab", "tadin_project": ["Backend", "Frontend"]}	2026-05-21 23:11:53.15466	2026-05-21 23:11:53.154681	\N	\N	\N
97514ebe-ee51-46f1-b655-d08a38232eff	e44083dd-0913-4bb5-b107-afb978377446	\N	En el chat global de oficinas hay que agregar el boton de cancelar cuando se manda mensaje , no lo tiene (Arreglado)		done	normal	\N	41	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3656d245-8bcb-801c-80d1-ed839bc98f7f", "tadin_project": []}	2026-05-21 23:11:55.26459	2026-05-22 08:14:58.954904	\N	\N	\N
dd4efb77-96e3-4c92-a25d-f07063840cf4	e44083dd-0913-4bb5-b107-afb978377446	\N	Error en el chat global al manger llamar a determinados agentes.(Frontend)	Errores de WebSocket, button anidado, hydration error.	done	urgent	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3656d245-8bcb-8058-976b-ecdc64e37a12", "tadin_project": []}	2026-05-21 23:11:31.170142	2026-05-22 14:05:36.393357	\N	\N	\N
3e5c3389-50c7-4495-9cfc-a2f9275bea33	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar los tweks de mensajes(similar a whatsapp o telegram)		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3156d245-8bcb-80d8-ba33-ee81cd24cadd", "tadin_project": []}	2026-05-22 14:14:45.572094	2026-05-22 14:14:45.572112	\N	\N	\N
45637336-9b66-473d-9d81-37afe371a880	e44083dd-0913-4bb5-b107-afb978377446	\N	Arreglar boton de Nueva ApiKey en el Paso 2 de crear agente y en herramientas modificar la vista(mejorarla)		done	normal	\N	4	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3656d245-8bcb-8012-9b35-f7d75eada0c4", "tadin_project": []}	2026-05-21 23:11:45.116668	2026-05-22 08:14:58.697586	\N	\N	\N
7fee32db-394a-41c8-9c99-4b688523db70	e44083dd-0913-4bb5-b107-afb978377446	\N	Sin conrifmacion en menus de liminar	Al borrar un agente, api key o cualquier otro botón de eliminar no existe menú de confirmación. Debe haber modal de confirmación de eliminación para cada botón que elimine algo.	done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3176d245-8bcb-8063-9d3f-e6afe1ad921b", "tadin_project": []}	2026-05-22 14:14:45.589066	2026-05-22 14:14:45.58909	\N	\N	\N
a27e1060-3c97-43eb-92ff-73e8c6177615	e44083dd-0913-4bb5-b107-afb978377446	\N	Los plugins de antropic que necesitan mcp no tienen par agregar las credenciales	Agregar en la base de datos y que se borren cuando se borre el agente o el plugin. Permitir el manejo de múltiples credenciales y poder seleccionar la credencial deseada para cada agente al crearlo.	backlog	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3366d245-8bcb-80ec-b4be-f118c75adba5", "tadin_project": ["Backend", "Frontend"]}	2026-05-22 14:14:45.617931	2026-05-22 14:14:45.617975	\N	\N	\N
b120837c-c539-41fd-bd4b-9f927641e657	e44083dd-0913-4bb5-b107-afb978377446	\N	El builder agent durante la creación de agentes de una oficina me creó un agente duplicado		done	low	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "33d6d245-8bcb-8069-a097-c025fae85fe5", "tadin_project": ["Backend"]}	2026-05-22 14:14:45.622949	2026-05-22 14:14:45.622966	\N	\N	\N
838e44ff-94d9-402a-a241-cee6ba782d76	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar botones dejar que la barra de navegación se mantenga en la parte superior en las oficinas		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3446d245-8bcb-8006-bcd9-c5060a0eb02b", "tadin_project": []}	2026-05-22 14:14:45.625953	2026-05-22 14:14:45.625969	\N	\N	\N
84849db3-2f4d-4d3e-bcdc-486d66acc432	e44083dd-0913-4bb5-b107-afb978377446	\N	Hacer que los canales funcionen por oficina yy no gloval		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3446d245-8bcb-80f4-a2ae-c6a7bd662338", "tadin_project": []}	2026-05-22 14:14:45.639205	2026-05-22 14:14:45.639224	\N	\N	\N
07db5a37-f0df-42bd-a545-01ed8524fe71	e44083dd-0913-4bb5-b107-afb978377446	\N	Manejar las credenciales de las extenciones		done	urgent	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3496d245-8bcb-8077-b20d-eb4fd597c3cf", "tadin_project": []}	2026-05-22 14:14:45.641139	2026-05-22 14:14:45.641155	\N	\N	\N
1b34b0f0-112e-4e7c-8b5c-b4e60e6dc87c	e44083dd-0913-4bb5-b107-afb978377446	\N	En los canales de wsapp cuando agregas un contacto a la lista blanca selecccionando el contacto en lugar de escribir el numero , no funciona (sigue sin responder al usuario )		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3586d245-8bcb-80c2-9c5c-c41c5b2ada39", "tadin_project": []}	2026-05-22 14:14:45.645446	2026-05-22 14:14:45.64547	\N	\N	\N
ae2aecca-ae03-4fc5-a69c-3529e617e316	e44083dd-0913-4bb5-b107-afb978377446	\N	Agregar barra de progreso cuando se esta subiendo una nueva base de conocimiento		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "35a6d245-8bcb-808c-8974-e75d5f99cd19", "tadin_project": []}	2026-05-22 14:14:45.647062	2026-05-22 14:14:45.647086	\N	\N	\N
5ae743d6-7cde-4e4b-bf99-523ecea53ea2	e44083dd-0913-4bb5-b107-afb978377446	\N	editar mensaje en el back debe borrarse del historial		done	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3176d245-8bcb-8090-a70c-e560a6328c56", "tadin_project": ["Backend"]}	2026-05-22 14:27:56.759019	2026-05-22 14:27:56.759048	\N	\N	\N
723801a1-eec5-4c16-9c05-b80d1b566895	e44083dd-0913-4bb5-b107-afb978377446	\N	Nesesario agregar persistencia para almacenar la ruta al workspace		done	high	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3176d245-8bcb-8041-8d89-f6aaed17dafd", "tadin_project": []}	2026-05-22 14:27:56.760706	2026-05-22 14:27:56.760737	\N	\N	\N
46205602-5317-4bd4-8f0b-2ccc9b7286b7	e44083dd-0913-4bb5-b107-afb978377446	\N	NO se cancela la creacion de documento, se cuelga la pc en windows		done	normal	\N	0	fc7a4bb9-6b76-4db2-9a18-0916159aa890	{"tadin_id": "3676d245-8bcb-8069-afa6-da6cc586a45e", "tadin_project": []}	2026-05-22 14:14:45.658235	2026-05-22 19:44:06.480065	\N	\N	\N
\.


--
-- Data for Name: user_devices; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.user_devices (id, user_id, fcm_token, platform, last_seen, created_at) FROM stdin;
941997e8-8c46-4d55-adf5-9c8f2f8707a7	fc7a4bb9-6b76-4db2-9a18-0916159aa890	dNpnGrjzTPe9W4TpT9XXVD:APA91bEXsPOkSnSkc6-gKkiynm16mB3gbpvkTJFl9QfexhtuzaP_SgZX8MF7stpzFc8CEq6m-i6BZ4b6RJpo3-kVfPyB48MqLN0qevJsBYJ-qv4pAL9hJAM	android	2026-05-25 17:45:03.232689	2026-05-22 05:04:54.910193
1d5e20f7-2fc9-4a33-96f6-ab99004cd5fc	85640f10-ec4c-4088-b6ff-41cb2031aae8	dVAHdMDsQJC4vCApLdNKIA:APA91bEGr3PnG908E-igG0s4xbHPTmZzklpxkoyu_wlA_Z5Ww7h_ZoaUkAXkIh_SLCEFpCAEvMGsaYbqXfzC8BkIbw4XN4ovf0-LyMmPVWzX3M70fqaaDyc	android	2026-05-25 18:26:25.332736	2026-05-25 18:24:42.028993
864d514c-597d-4c8b-b7a7-e15a53f44d43	56f1614d-e66d-4d93-b090-33e03c34d084	dy25K58PTX2Jc5AI6EjK-E:APA91bFXlLq3crWIf4fLQCyc8M66Nf_Ox1c3QOp2Ofan4A3nvWIYx7v9Uq2ZhSNreVF_Un4-zO78qiWKazbknGE7RWvwmfuFtrFKXJtTMfyjU068MUN2-oA	android	2026-05-26 03:50:48.157106	2026-05-22 05:12:51.519266
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: tareapp
--

COPY public.users (id, email, name, password_hash, is_active, created_at, role) FROM stdin;
c91275b3-f5da-4c2a-a3da-17846f534ef3	chang.serranokmll@gmail.com	Camila Serrano Chang	$2b$12$ws7yuzx274kM3hz5soFmuOpiq0ZsSP1De.2dZ5KVAUGGpMFReSP1q	t	2026-05-21 23:11:06.559458	member
56f1614d-e66d-4d93-b090-33e03c34d084	davidrr1733@gmail.com	David	$2b$12$ufAjKAC.W18I2XcMbRGmE.OHL4UMUBttatpuZrFKp.Vs/RYYIidFK	t	2026-05-21 23:11:04.526499	member
a9a0509e-c92a-4242-802b-f5136b06a5df	carlostorralbasperez@gmail.com	Carlito GamerYT	$2b$12$ZForY37Ycn0uXODw8LmUCOJRRr/nvNBBdvel.6QfUbnPvILpXVlYi	t	2026-05-21 23:11:03.569522	member
dc0e6661-e250-45aa-98f4-d3ec82c21015	allan.pierra@gmail.com	Allan Pierra	$2b$12$TKLPmj3foTY4LZPwcEJuaeuol2m1KCW6Yd8rHE66bZMOQ65PVXQCu	t	2026-05-22 05:21:37.493765	member
fc7a4bb9-6b76-4db2-9a18-0916159aa890	halexysvelasques@gmail.com	Halexy	$2b$12$Ot137as0h2pQZLb8E9mhDO4hguEC3VJy1dEZ77e.3Ys7QowNQU0ze	t	2026-05-21 17:46:20.333179	admin
85640f10-ec4c-4088-b6ff-41cb2031aae8	luislzro141@gmail.com	Luis 141	$2b$12$EsshmSdQC89sz2GiWJV/ne9zEyndtIbB0LnWUpL/7pf7nCqYGq86S	t	2026-05-21 23:11:02.668472	member
\.


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: error_reports error_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.error_reports
    ADD CONSTRAINT error_reports_pkey PRIMARY KEY (id);


--
-- Name: ingest_keys ingest_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.ingest_keys
    ADD CONSTRAINT ingest_keys_pkey PRIMARY KEY (id);


--
-- Name: ingest_keys ingest_keys_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.ingest_keys
    ADD CONSTRAINT ingest_keys_token_hash_key UNIQUE (token_hash);


--
-- Name: labels labels_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_pkey PRIMARY KEY (id);


--
-- Name: mcp_tokens mcp_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.mcp_tokens
    ADD CONSTRAINT mcp_tokens_pkey PRIMARY KEY (id);


--
-- Name: mcp_tokens mcp_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.mcp_tokens
    ADD CONSTRAINT mcp_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: saved_filters saved_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.saved_filters
    ADD CONSTRAINT saved_filters_pkey PRIMARY KEY (id);


--
-- Name: task_assignees task_assignees_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.task_assignees
    ADD CONSTRAINT task_assignees_pkey PRIMARY KEY (task_id, user_id);


--
-- Name: task_labels task_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.task_labels
    ADD CONSTRAINT task_labels_pkey PRIMARY KEY (task_id, label_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: error_reports uq_error_project_signature; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.error_reports
    ADD CONSTRAINT uq_error_project_signature UNIQUE (project_id, signature);


--
-- Name: labels uq_label_project_name; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT uq_label_project_name UNIQUE (project_id, name);


--
-- Name: user_devices user_devices_fcm_token_key; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_fcm_token_key UNIQUE (fcm_token);


--
-- Name: user_devices user_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_activities_task; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE INDEX ix_activities_task ON public.activities USING btree (task_id);


--
-- Name: ix_comments_task; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE INDEX ix_comments_task ON public.comments USING btree (task_id);


--
-- Name: ix_error_reports_last_seen; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE INDEX ix_error_reports_last_seen ON public.error_reports USING btree (last_seen);


--
-- Name: ix_error_reports_project_status; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE INDEX ix_error_reports_project_status ON public.error_reports USING btree (project_id, status);


--
-- Name: ix_ingest_keys_project; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE INDEX ix_ingest_keys_project ON public.ingest_keys USING btree (project_id);


--
-- Name: ix_ingest_keys_token; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE UNIQUE INDEX ix_ingest_keys_token ON public.ingest_keys USING btree (token_hash);


--
-- Name: ix_mcp_tokens_token_hash; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE UNIQUE INDEX ix_mcp_tokens_token_hash ON public.mcp_tokens USING btree (token_hash);


--
-- Name: ix_task_parent; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE INDEX ix_task_parent ON public.tasks USING btree (parent_task_id);


--
-- Name: ix_task_project_status; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE INDEX ix_task_project_status ON public.tasks USING btree (project_id, status);


--
-- Name: ix_tasks_status; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE INDEX ix_tasks_status ON public.tasks USING btree (status);


--
-- Name: ix_user_devices_user; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE INDEX ix_user_devices_user ON public.user_devices USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: tareapp
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: activities activities_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: activities activities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: comments comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: comments comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: error_reports error_reports_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.error_reports
    ADD CONSTRAINT error_reports_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: error_reports error_reports_linked_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.error_reports
    ADD CONSTRAINT error_reports_linked_task_id_fkey FOREIGN KEY (linked_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: error_reports error_reports_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.error_reports
    ADD CONSTRAINT error_reports_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: ingest_keys ingest_keys_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.ingest_keys
    ADD CONSTRAINT ingest_keys_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ingest_keys ingest_keys_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.ingest_keys
    ADD CONSTRAINT ingest_keys_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: labels labels_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: mcp_tokens mcp_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.mcp_tokens
    ADD CONSTRAINT mcp_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: projects projects_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: saved_filters saved_filters_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.saved_filters
    ADD CONSTRAINT saved_filters_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: saved_filters saved_filters_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.saved_filters
    ADD CONSTRAINT saved_filters_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_assignees task_assignees_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.task_assignees
    ADD CONSTRAINT task_assignees_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_assignees task_assignees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.task_assignees
    ADD CONSTRAINT task_assignees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_labels task_labels_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.task_labels
    ADD CONSTRAINT task_labels_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.labels(id) ON DELETE CASCADE;


--
-- Name: task_labels task_labels_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.task_labels
    ADD CONSTRAINT task_labels_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_parent_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_parent_task_id_fkey FOREIGN KEY (parent_task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: user_devices user_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tareapp
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Ay9JvPoPzwrVnEAI1eiD0p44YGNHJxW7Pl6Ztfw6l7CEuPrJmcMokjNkzDXaFhq

